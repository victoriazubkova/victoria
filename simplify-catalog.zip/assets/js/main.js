const hashTable = {
  'external report': 'extreport',
  'other external content': 'extcontent',
  'internal report': 'report',
  'metric': 'chart'
}

function setState(state) {
  if (typeof localStorage?.setItem === 'function') {
    localStorage.setItem('nmslabState', JSON.stringify(state));

    return true;
  }

  return false;
}

function getState() {
  if (typeof localStorage?.getItem === 'function') {
    const state = localStorage.getItem('nmslabState');

    if (state) {
      try {
        return JSON.parse(state);
      } catch {
        return null;
      }
    }
  }

  return null;
}

const state = new Proxy(getState() || {}, {
  set: function (obj, prop, value) {
    obj[prop] = value;

    return setState(obj);
  },
});

function noItemMessage() {
  if ($('.dashboards__dashboard').children('.dashboard-item').length != 0) {
    $('.no-tile-message').hide();
    $('.dashboards__upper').show();
    $('.dashboards__dashboard').show();
    $('.dashboards').css({ background: '#FFFFFF' });
  } else {
    $('.no-tile-message').show();
    $('.dashboards__upper').hide();
    $('.dashboards__dashboard').hide();
    $('.dashboards').css({ background: 'none' });
  }
}

//Functoin to change hex type color to rgb
function hexToRgb(hex) {
  // Remove the # character, if present
  hex = hex.replace('#', '');

  // Convert the hex value to RGB
  var r = parseInt(hex.substring(0, 2), 16);
  var g = parseInt(hex.substring(2, 4), 16);
  var b = parseInt(hex.substring(4, 6), 16);

  // Return the RGB values as an object
  return { r: r, g: g, b: b };
}

function announcementFunc(announcementTextWidth) {
  const $announcement = $('.announcement');
  const $announcementBlock = $('.announcement__text p span');

  $announcementBlock.css({
    display: 'block',
    'max-width': `${announcementTextWidth}px`,
    'text-overflow': 'ellipsis',
    overflow: 'hidden',
    'white-space': 'nowrap',
    visibility: 'hidden',
    opacity: '0',
  });

  $('.open-announce').on('click', function () {
    $announcement.addClass('js-toggle-announcement-text');

    $('.announcement__text p span').css({
      'max-width': '100%',
    });

    $announcementBlock
      .css({
        'text-overflow': 'unset',
        overflow: 'hidden',
        'white-space': 'unset',
      })
      .animate(
        {
          'max-height': '500px',
        },
        300,
      );
  });

  $('.close-announce').on('click', function () {
    $announcement.removeClass('js-toggle-announcement-text');

    if ($('.pp-page').hasClass('js-sidebar-opened')) {
      $announcementBlock
        .css({
          'max-width': `${announcementTextWidth - 216}px`,
          'text-overflow': 'ellipsis',
          overflow: 'hidden',
          'white-space': 'nowrap',
        })
        .animate(
          {
            'max-height': '36px',
          },
          300,
        );
    } else {
      $announcementBlock
        .css({
          'max-width': `${announcementTextWidth}px`,
          'text-overflow': 'ellipsis',
          overflow: 'hidden',
          'white-space': 'nowrap',
        })
        .animate(
          {
            'max-height': '36px',
          },
          300,
        );
    }


  });
}

function getDayOfWeek(dateString) {
  const daysOfWeek = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  const date = new Date(dateString);
  const dayOfWeek = daysOfWeek[date.getDay()];
  return dayOfWeek;
}

function formatDate(dateString) {
  const dateParts = dateString.split('-');
  const formattedDate = `${dateParts[1]}/${dateParts[2]}/${dateParts[0]}`;
  return formattedDate;
}

function dashboardDynamics() {
  const $tab = $('.dashboards__tab');
  // const $docs = $('.dashboards__docs');
  const tileView = $('.tile');
  const listView = $('.list');

  if ($tab?.length) {
    $tab[0].click();

    $tab.on('click', function () {
      const $this = $(this);
      const $tabTopic = $this.data('tag-tab-name');

      $this.siblings().removeClass('js-tab-active');
      $this.addClass('js-tab-active');

      $(`.dashboards__dashboard`).removeClass('js-viewing').hide();
      $(`.dashboards__dashboard[data-topic="${$tabTopic}"]`)
        .addClass('js-viewing')
        .show();
    });
  }

  tileView.on('click', function () {
    listView.removeClass('js-active');
    $(this).addClass('js-active');

    $('.dashboards__dashboard').removeClass('js-list-view');
    $('.dashboards__dashboard').addClass('js-tile-view');
  });

  listView.on('click', function () {
    tileView.removeClass('js-active');
    $(this).addClass('js-active');

    $('.dashboards__dashboard').removeClass('js-tile-view');
    $('.dashboards__dashboard').addClass('js-list-view');
  });

  tileView.click();
}

function infoPopup($infoBlock) {
  let timer;
  //Add info popup on hover
  $(document).on('mouseenter', '.info-btn', function () {
    if (timer) {
      clearTimeout(self.timer);
    }

    //Adding custom fields to info popup
    dash.customFieldsDisplayOnTileInfo = {
      "used_for_metric_ind": "Y",
      "used_for_report_ind": "Y",
      "used_for_external_report_ind": "Y",
      "used_for_external_report_ind": "Y"
    };

    $infoBlock.html(
      MI.PortalPageView.buildElementInfoPopup($(this).data('info-id')),
    );

    let maxRight = $(window).width() - $infoBlock.outerWidth();
    let maxTop = $(window).height() - $infoBlock.outerHeight() - 40;
    let hoverItemRect = this.getBoundingClientRect();
    let left = hoverItemRect.right;
    let top = hoverItemRect.top;
    let right = left + $infoBlock.outerWidth();
    let bottom = top + $infoBlock.outerHeight();

    //Cheking if hovered item to close to right side of viewport. Then init position popup on the left side
    if (right > maxRight) {
      left = hoverItemRect.left - $infoBlock.outerWidth();
    }
    //Cheking if hovered item to close to bottom side of viewport. Then init position popup on the top side
    if (top > maxTop) {
      top = maxTop - 30;
    }

    $infoBlock.css({
      top: top - 20,
      left: left,
    });

    // Consider scroll position
    const scrollTop = $(window).scrollTop();
    const adjustedTop = top + scrollTop;

    $infoBlock.css({
      top: adjustedTop - 20
    });

  });

  $(document).on('mouseenter', '.info-block', function () {
    if (timer) {
      clearTimeout(timer);
    }
  });

  //Remove info popup on mouse out
  $(document).on('mouseleave', '.info-btn', function () {
    timer = setTimeout(function () {
      $infoBlock.html('');
    }, 300);
  });

  $(document).on('mouseleave', '.info-block, .el-info-cart', function () {
    timer = setTimeout(function () {
      $infoBlock.html('');
    }, 300);
  });
}

function formatTitleText(text, row, lastRow) {
  let formattedText = '';
  const lines = text.split('\n');
  for (let line of lines) {
    if (line.length > row) {
      const words = line.split(' ');
      let newLine = '';
      for (let word of words) {
        if (word.length > row) {
          const slicedWord = word.slice(0, row) + '<br>' + word.slice(row);
          newLine += slicedWord + ' ';
        } else {
          newLine += word + ' ';
        }
      }
      line = newLine.trim();
    }
    if (line.length > lastRow) {
      line = line.slice(0, lastRow - 3) + '...';
    }
    formattedText += line + '<br>';
  }
  return formattedText.slice(0, -4);
}

function findParentNames(obj) {
  const names = [];

  //Object with prepared folder name and id
  const newObj = {
    name: obj.name,
    folder_id: obj.folder_id
  }

  if (obj) {
    names.push(newObj);

    if (obj.parent) {
      // names.push(obj.parent.name);
      names.push(...findParentNames(obj.parent));
    }
  }
  return names;
}

class simplyfyCatalog {
  constructor(props) {
    this.enableTopbarHide = props.enableTopbarHide;
    this.customTopbar = props.customTopbar;
    this.topbarBackgroundColor = props.topbarBackgroundColor;
    this.topbarColor = props.topbarColor;
    this.topbarHighlightColor = props.topbarHighlightColor;
    this.portalPageBackground = props.portalPageBackground;
    this.mainPageColor = props.mainPageColor;
    this.enableSearchbar = props.enableSearchbar || 'N';

    this.enableCustomMIPopup = props.enableCustomMIPopup;

    this.announcementsLink = props.announcementsLink;
    this.multifolderSelect = props.multifolderSelect;
    this.elementPreviewType = props.elementPreviewType;
    this.announcementWrapper = $('.announcement');
    this.tagsVariable = props.tagsVariable;
    this.announcements = props.announcements;
    this.globalSidebarFolders = props.globalSidebarFolders;
    this.chosenElementsId = props.chosenElementsId;
    this.externalContentDataset = props.externalContentDataset;


    this.width = $(window).width();
    this.height = $(window).height() - 87;

    this.annauncementWidth = $('.announcement__description-block').width() - 130;

    this.pageInternalName = document.location.href.split('?')[0].split('/')[4];

    // this.announcementTextWidth = $('.announcement__description-block').width() - 336;

    this.globalFullObject = [];

    this.sidebarBottomLinks = props.sidebarBottomLinks;

    this.favoritesFolder = '';

    // Global colors variable
    this.colors = colorsFT;

    /**
     * @type {NavigationBar}
     */
    this.navigationBar = props.navigationBar;

    this.folderChilds = {};
  }

  init() {
    const $tagTabsWrapper = $('.dashboards__tabs');
    const $dashboards = $('.dashboards');
    const $announcementTitle = $('.announcement__lower-title');
    const self = this;

    this.initSwitchersByVariables();

    switch(this.enableSearchbar) {
      case 'Y':
        $('.pp-searchbar').show();
        break;
      case 'N':
        $('.pp-searchbar').hide();
        break;
    }

    //Announcement
    if (this.announcements) {

      this.fetchAnnouncement()
        .then((response) => {

          for (const announcementData of response.announcements) {
            if (announcementData.id == self.announcements) {
              const announcement = announcementData;

              $announcementTitle.append(announcement.subject);
              $('.announcement__text').prepend(announcement.html_code);

              announcementFunc(self.annauncementWidth);

              setTimeout(() => {
                if ($('.pp-page').hasClass('js-sidebar-opened')) {
                  $('.announcement__text p span').css({
                    'max-width': `${self.annauncementWidth - 216}px`,
                    visibility: 'visible',
                    opacity: '1',
                  });

                  $('.js-toggle-announcement-text .announcement__text p span').css({
                    'max-width': '100% !important',
                  });
                } else {
                  $('.announcement__text p span').css({
                    'max-width': `${self.annauncementWidth}px`,
                    visibility: 'visible',
                    opacity: '1',
                  });

                  $('.js-toggle-announcement-text .announcement__text p span').css({
                    'max-width': '100% !important',
                  });
                }
              }, 500);
            }
          }


        })
        .catch(() => {
          this.announcementWrapper.hide();
        });
    } else {
      this.announcementWrapper.hide();
    }

    if (this.announcementsLink == '') {
      $('.announcements-link').hide();
    } else {
      $('.announcements-link').show();
    }

    $(document).on('click', '.js-menu-close-btn', function () {

      if ($('.announcement').hasClass('js-toggle-announcement-text')) {
        $('.announcement__text p span').css({
          'max-width': `100% !important`,
        });
      } else {
        $('.announcement__text p span').css({
          'max-width': `${self.annauncementWidth}px`,
        });
      }

    });

    $(document).on('click', '.pp-left-bar-btn', function () {

      if ($('.announcement').hasClass('js-toggle-announcement-text')) {
        $('.announcement__text p span').css({
          'max-width': `100% !important`,
        });
      } else {
        $('.announcement__text p span').css({
          'max-width': `${self.annauncementWidth - 216}px`,
        });
      }

    });

    // sidebarFunc();

    //Build Tag tabs and dasboards
    if (this.tagsVariable?.length && this.multifolderSelect == 'N') {
      for (let tag of this.tagsVariable) {
        const tagItem = tag['Tag'];
        const tagName = tag['Tag name'];
        const tagTooltip = tag['Tooltip'];

        $tagTabsWrapper.append(`
              <div class="dashboards__tab" data-tag-tab-name="${tagItem}" data-tooltip-text="${tagTooltip}">
                ${tagName}
              </div>
        `);

        $dashboards.append(`
          <div data-topic="${tagItem}" class="dashboards__dashboard">
            <div class="dashboard-upper-list">
              <span class="dashboard-upper-list__name">Report name</span>
              <span class="dashboard-upper-list__tags">Tags</span>
              <span class="dashboard-upper-list__last-viewed">Last Viewed</span>
              <span class="dashboard-upper-list__engagement">Engagement</span>
            </div>
            <div class="no-items-message" style="display: none;"></div>
          </div>
        `);
        dashboardDynamics();
      }
    } else if (this.tagsVariable?.length && this.multifolderSelect === 'Y') {
      $dashboards.append(`
          <div class="dashboards__dashboard">
            <div class="dashboard-upper-list">
              <span class="dashboard-upper-list__name">Report name</span>
              <span class="dashboard-upper-list__tags">Tags</span>
              <span class="dashboard-upper-list__last-viewed">Last Viewed</span>
              <span class="dashboard-upper-list__engagement">Engagement</span>
            </div>
            <div class="no-items-message" style="display: none;"></div>
          </div>
        `);

      dashboardDynamics();
    }



    new Promise((resolve) => {
      $.ajax({
        url: '/home/index/refresh/ajax/Y?with_topics=Y',
        dataType: 'json',
      }).done(function (response) {
        dash.InitForPortalPage(response);
        resolve();
      });
    }).then(async () => {
      const rows = dash.db.Get();
      const $dashboard = $('.dashboards__dashboard');

      for (const element of rows) {
        this.globalFullObject.push({
          element_id: element.element_id,
          element_dashboard_name: element.element_dashboard_name,
          user_dashboard_element_instance_id:
            element.user_dashboard_element_instance_id,
          element_type: element.element_type,
          segment_value_id: element.segment_value_id,
          content_type: element.content_type,
          element_type: element.element_type,
          topics: element.topics,
          user_id: element.user_id,
          in_favorites: element.in_favorites,
          is_in_favorites: element.is_in_favorites,
          folder_id: element.folder_id,
          user_id: element.user_id,
          section_type: element.section_type,
          has_access: element.has_access,
          total_view_count: element.global_total_view_count,
          certified_ind: element.certified_ind,
          certification_level_id: element.certification_level_id,
          certification_level_name: element.certification_level_name,
          certification_level_color: element.certification_level_color
        });
      }

      await this.recentlyViewedItems().then((resp) => {
        for (const item of this.globalFullObject) {
          for (let view of resp.views) {
            if (item.element_id === view.element_id) {
              item.last_view_time = view.last_view_time;
            }
          }
        }
      });

      // for(const element of this.globalFullObject) {
      //   this.getElementImage(element.element_id, element.segment_value_id).then((resp) => {
      //     element.thumbnail = resp.images.thumbnail;
      //   })
      // }

      const topicIds = Array.from(
        new Set(
          this.globalFullObject
            .map((item) => item.topics)
            .reduce((prev, curr) => {
              prev.push(...curr);

              return prev;
            }, []),
        ),
      );
      const topicsData = [];

      for (const id of topicIds) {
        topicsData.push(this.fetchTopics(id));
      }

      const parsedTopicsData = (await Promise.all(topicsData))
        .map((v) => v.topic)
        .reduce((prev, curr) => {
          prev[curr.id] = curr;

          return prev;
        }, {});

      //Function to build dashboard with single folder support
      const buildDashboard = function (elements, folderName) {
        $dashboard.find('.dashboard-item').remove();

        for (const element of self.globalFullObject.filter(
          (el) => el.section_type == 'Category',
        )) {

          const topics = element.topics;

          /* Get Topics */
          if (topics?.length && self.tagsVariable?.length) {
            for (const topic of topics) {

              if (parsedTopicsData[topic]) {
                const topicData = parsedTopicsData[topic];

                //Add id attribute to dashboards
                $dashboard.each(function (i) {
                  const $this = $(this);

                  if ($this.data('topic') == topicData.name) {
                    for (const item of elements) {
                      if (element.element_id == item) {
                        self.buildDashboardItem($this, element, folderName);
                      }
                    }
                  }

                  if ($this.children('.dashboard-item').length !== 0) {
                    $this.find('.no-items-message').hide();
                    $this.find('.no-items-message').html('');
                  } else {
                    $this.find('.no-items-message').show();
                    $this
                      .find('.no-items-message')
                      .html(
                        'There are no items available from this folder for this tag',
                      );
                  }
                });
              }
            }
          }
          if (self.tagsVariable.length == 0) {

            //If multifolder selected to N build basic structure
            if (this.multifolderSelect == 'N') {
              $dashboard.each(function (i) {
                const $this = $(this);

                for (const item of elements) {
                  if (+element.element_id === item) {
                    self.buildDashboardItem($this, element, folderName);
                  }
                }

                if ($this.children('.dashboard-item').length !== 0) {
                  $this.find('.no-items-message').hide();
                  $this.find('.no-items-message').html('');
                } else {
                  $this.find('.no-items-message').show();
                  $this
                    .find('.no-items-message')
                    .html(
                      'There are no items available from this folder for this tag',
                    );
                }
              });
            }

          }

        }
      }

      //Function to build dashboard with multifodler as at the catalog
      const buildDashboardWithMultifolder = function (elements, folderName) {
        const filteredElements = elements.filter(
          (el) => el.section_type == 'Category',
        );

        if (filteredElements.length) {
          for (const element of filteredElements) {
            self.buildDashboardItem(
              $('.dashboards__dashboard'),
              element,
              folderName,
            );
          }
        }

        noItemMessage();

        $('.dashboard-item').each((i, item) => {
          if ($(item).data('access') == 'N') {
            $(item).find('.favorite-btn').hide();
          }
        });
      }

      $(document).on('click', '.js-menu-title', function () {
        const $this = $(this);

        $('.dashboards__title').html($this.data('folder-name'));
        $('.pp-searchbar__input').val('');

        if (self.multifolderSelect == 'N' || self.multifolderSelect == '') {
          const elements = $this.data('elements');
          const folderName = $this.data('folder-name');

          buildDashboard(elements, folderName);

          $('.dashboard-item__tags').each((i, item) => {
            for (const tag of $(item).data('topics')) {
              self.fetchTopics(tag).then((res) => {
                $(item).append(`
                  <span class="dashboard-item__tags-tag">${res.topic.name}</span>
                `);
              });
            }
          });

        }

        if (self.multifolderSelect === 'Y') {

          self.navigationBar.inited.then(() => {

            if (!Object.keys(self.folderChilds).length) {
              const folders = self.navigationBar.loadedFoldersData.sort(
                (a, b) => {
                  return a.parent_folder_id - b.parent_folder_id;
                },
              );

              for (const folder of folders) {
                if (!self.folderChilds[folder.folder_id]) {
                  self.folderChilds[folder.folder_id] = folder;
                }

                if (folder.parent_folder_id && self.folderChilds[folder.parent_folder_id]) {
                  if (!self.folderChilds[folder.parent_folder_id].childs) {
                    self.folderChilds[folder.parent_folder_id].childs = {};
                  }

                  self.folderChilds[folder.parent_folder_id].childs[
                    folder.folder_id
                  ] = self.folderChilds[folder.folder_id];

                  self.folderChilds[folder.folder_id].parent =
                    self.folderChilds[folder.parent_folder_id];
                }
              }
            }

            const $list = $this.next();

            const folderId = $list.data('nav-folder');

            const subfolderElements = self.getSubfolderElementsDeep(
              self.folderChilds[folderId],
            );

            for (const [folderId, sEl] of Object.entries(subfolderElements)) {
              const folder = self.folderChilds[folderId];

              let folderBreadcrumbsArray = findParentNames(folder).reverse();

              let $breadcrumbsWrapper = $('<div>');

              $breadcrumbsWrapper.addClass('elements-breadcrumbs');

              $('.dashboards__dashboard').append($breadcrumbsWrapper);

              for (const fbItem of folderBreadcrumbsArray) {
                let input = `<span class="elements-breadcrumbs__item" data-folder-id="${fbItem.folder_id}" data-folder="${fbItem.name}">${fbItem.name}</span>`;

                $breadcrumbsWrapper.append(input);
              }

              buildDashboardWithMultifolder(sEl, folder.name);
            }

            noItemMessage();
          });

          $dashboard.find('.dashboard-item').remove();
          $dashboard.find('.elements-breadcrumbs').remove();

          $('.dashboard-item__tags').each((i, item) => {
            for (const tag of $(item).data('tags')) {
              self.fetchTopics(tag).then((res) => {
                $(item).append(`
                  <span class="dashboard-item__tags-tag">${res.topic.name}</span>
                `);
              });
            }
          });
        }

        state.clickedFolder = $this.data('folder-name');
      });

      $(document).on('click', '.elements-breadcrumbs__item', function () {
        const $this = $(this);

        if ($this.data('folder') && $this.data('folder-id')) {
          $(`.js-menu-title[data-folder-name="${$this.data('folder')}"][data-nav-folder-id="${$this.data('folder-id')}"]`).click();
        }
      });

      const sortedElemsArray = this.globalFullObject.sort(function (a, b) {
        const dateA = new Date(a.last_view_time);
        const dateB = new Date(b.last_view_time);
        return dateB - dateA;
      });

      //Choose unique elements by elements name (if check by id it can be duplicated becouse of most popular folder or few favorites folders)
      let uniqueFavoriteObjects = $.grep(
        sortedElemsArray.filter((el) => el.section_type == 'Favorite'),
        function (obj, index) {
          return (
            $.inArray(
              obj.element_dashboard_name,
              $.map(
                sortedElemsArray.filter((el) => el.section_type == 'Favorite'),
                function (obj) {
                  return obj.element_dashboard_name;
                },
              ),
            ) === index
          );
        },
      );

      //Build Favorites
      for (const sortedItem of uniqueFavoriteObjects) {
        if (
          sortedItem.is_in_favorites == '1' &&
          sortedItem.section_type == 'Favorite'
        ) {
          this.buildSideItem('append', $('.favorites__main'), sortedItem);
        }
      }

      //Build recently viewed column
      const sortedEntitiesArray = [];
      //Get existing entities
      this.getEntities('Recently Viewed', this.pageInternalName).then(
        (entities) => {
          entities.map((entity) => {
            sortedEntitiesArray.push(entity.value);
          });
        },
      );

      //Sort entity array by date
      sortedEntitiesArray.sort(function (a, b) {
        const dateA = new Date(a.last_view_time);
        const dateB = new Date(b.last_view_time);
        return dateB - dateA;
      });

      //slice array if entities to 20 items
      const slicedEntitiesArray = sortedEntitiesArray.slice(0, 20);

      //Append elements from sorted and sliced array
      for (const cuttedItem of slicedEntitiesArray) {
        if (cuttedItem.last_view_time) {
          this.buildSideItem('append', $('.recently-viewed__main'), cuttedItem);
        }
      }

      const recentlyViewedObj = [];

      $(document).on(
        'click',
        '.dashboard-item__main, .link-btn, .side-item',
        function () {
          const $this = $(this);

          self.getEntities('Recently Viewed').then((entities) => {

            for (const element of self.globalFullObject) {
              if (element.element_id == $this.data('element-id') && element.segment_value_id == $this.data('segment')) {
                element.last_view_time = self.trackDateOnClick();

                //Check if array is not empty
                if (entities?.length) {
                  //Flag to check if entity is alrady exist
                  let entityExist = false;

                  for (const entetyItem of entities) {
                    //If entity id is same as element id update entity item
                    if (entetyItem.id == $this.data('element-id') && entetyItem.value.segment_value_id == $this.data('segment')) {
                      //Refresh item with new date to recently viewed column
                      $(
                        `.recently-viewed__main .side-item[data-element-id="${$this.data(
                          'element-id',
                        )}"][data-segment="${$this.data(
                          'segment',
                        )}"]`,
                      ).remove();
                      self.buildSideItem(
                        'prepend',
                        $('.recently-viewed__main'),
                        element,
                      );

                      self.updateEntity(
                        'Recently Viewed',
                        element,
                        entetyItem.id,
                      );
                      entityExist = true;
                      break;
                    }
                  }
                  //If entity array is empty add new one
                  if (!entityExist) {
                    //Add item with new date to recently viewed column
                    self.buildSideItem(
                      'prepend',
                      $('.recently-viewed__main'),
                      element,
                    );

                    self.addEntities(
                      'Recently Viewed',
                      element,
                      element.element_id,
                    );
                    break;
                  }
                } else {
                  //Add item with new date to recently viewed column
                  self.buildSideItem(
                    'prepend',
                    $('.recently-viewed__main'),
                    element,
                  );

                  self.addEntities(
                    'Recently Viewed',
                    element,
                    element.element_id,
                  );
                  break;
                }
              }
            }
          });
        },
      );

      //Open iframe window for report
      $(document).on('click', '.dashboard-item__main', function () {
        const $this = $(this);

        // MI.PortalPageView.openPreview($(this).data('info-id'));

        if ($this.data('page')) {
          window.open($this.data('page'), '_blank');
        }
      });

      $(document).on('click', '.side-item', function () {
        const $this = $(this);

        if ($this.data('page')) {
          window.open($this.data('page'), '_blank');
        }
      });

      const myPromise = new Promise((resolve, reject) => {
        // Some asynchronous operation, such as fetching data from an API
        const data = this.getFavorite();
        // Once the data is available, call the resolve function with the data
        resolve(data);
      });

      myPromise.then((data) => {
        const favorites = data.favorites;

        for (let i = 0; i < favorites.length; i++) {
          if (favorites[i].name === 'My Favorites') {
            this.favoritesFolder = favorites[i].id;

            this.favoriteToggle('.favorite-btn', this.favoritesFolder);
          }
        }
      });

      
      $(document).on('click', '.dashboard-item__main, .side-item', function () {
        const $this = $(this);
        const elementType = $this.data('type');
        const elementId = $this.data('element-id');
        const elementSegment = $this.data('segment');
        const reportType = $this.data('type');

        if (self.elementPreviewType == 'iframe') {

          if($this.parent().data('access') === 'Y' || $this.data('access') === 'Y') {
            
            let folderName = '';

            $('.pp-page').addClass('js-iframe-page');

            if ($this.data('folder-name')) {
              folderName = `<span class="pp-iframe__breadcrumbs-item">${$this.data(
                'folder-name',
              )}</span>`;
            } else {
              folderName = '';
            }

            $('.pp-iframe__breadcrumbs-chain').html(`
            ${folderName}
            <span class="pp-iframe__breadcrumbs-item">${$this.data(
              'element-name',
            )}</span>
          `);

            if ($('.pp-left-bar').hasClass('open')) {
              $('.js-menu-close-btn').trigger('click');
              $('.pp-left-bar-btn').hide();
            }

            $('.pp-left-bar-btn').hide();

            $('.pp-container').hide();
            $(document).find('.pp-iframe').css({ display: 'flex' });

            //Create iframe window
            $('.pp-iframe__wrapper').html(`
            <iframe style="width:${self.width - 30}px; height:${self.height - 30}px; border: none;" name="frame" id="frame" frameborder="0" 
            src="/${elementType}/index/preview/element/${elementId}/segment/${elementSegment}/width/${self.width - 30}/height/${self.height - 30}"></iframe>
          `);

            $('#frame').on('load', function () {
              $('#frame')
                .contents()
                .find('html')
                .addClass('without-scroll-fix');
            });
            

            $('.ui-dialog-titlebar-close').click();
          } else {
            if (self.enableCustomMIPopup == 'N' || self.enableCustomMIPopup == '') {
              $('.pp-access-denied__wrapper').show();
              $('.pp-access-denied').show();
            }

            if (self.enableCustomMIPopup === 'Y') {
              self.getElementInfo($this.data('element-id')).catch(err => {
                $('.pp-access-denied__wrapper').show();
                $('.pp-access-denied').show();

                console.log(err.responseJSON.message);

                $('.pp-access-denied__descr').html(`
                  ${err.responseJSON.message}
                `)

                $('.submit-popup').hide();
              });
            }
          }
        } else {
          if ($this.parent().data('access') === 'N' || $this.data('access') === 'N') {

            if (self.enableCustomMIPopup == 'N' || self.enableCustomMIPopup == '') {
              $('.pp-access-denied__wrapper').show();
              $('.pp-access-denied').show();
            }

            if (self.enableCustomMIPopup === 'Y') {
              self.getElementInfo($this.data('element-id')).catch(err => {
                $('.pp-access-denied__wrapper').show();
                $('.pp-access-denied').show();

                console.log(err.responseJSON.message);

                $('.pp-access-denied__descr').html(`
                  ${err.responseJSON.message}
                `)

                $('.submit-popup').hide();
              });
            }

          } else {
            MI.PortalPageView.openPreview($(this).attr('data-info-id'));
          }
        }
      });

      const user = await this.getUser();

      const { groups } = user;
      const userGroups = groups;

      console.log(userGroups);

      if (typeof userGroups != 'undefined') {
        if (
          typeof state.clickedFolder === 'undefined' ||
          !state.clickedFolder
        ) {
          let menuElem = '';

          $('.pp-left-bar-menu__title').each((i, item) => {
            let defaultArr = $(item).data('default-group-id');

            if (defaultArr?.length) {
              for (const userGroup of userGroups) {
                defaultArr.find(id => {

                  if (id == userGroup.group_id) {
                    menuElem = $(`.pp-left-bar-menu__title[data-default-group-id="[${defaultArr}]"]`);
                  }
                });
              }
            }
          })
          $(menuElem.get(0)).trigger('click');

        } else {
          setTimeout(() => {
            $(
              `.js-menu-title[data-folder-name="${state.clickedFolder}"]`,
            ).trigger('click');
          }, 200)
        }
      }

    });

    //Change iframe window size on resize of viewport
    $(window).resize(function () {
      if ($('.pp-page').hasClass('js-iframe-page')) {
        let $iframe = $('#frame');

        self.width = $(window).width();
        self.height = $(window).height() - 87;

        //Replace iframe's src to reload iframe
        let newSrc = $iframe.attr('src')
          .replace(/width\/\d+/, `width/${self.width - 5}`)
          .replace(/height\/\d+/, `height/${self.height - 25}`)

        $iframe.css({
          'width': self.width,
          'height': self.height
        })
        $iframe.attr('src', newSrc);
      }

    });

    //Close popup when click above it
    $(document).mouseup(function (e) {
      var popup = $('.pp-access-denied, .pp-access-requested');
      if (!popup.is(e.target) && popup.has(e.target).length === 0) {
        $('.pp-access-denied__wrapper').hide();
        popup.hide();
      }
    });

    $(document).on('click', '.cancel-popup, .submit-popup', function () {
      $('.pp-access-denied, .pp-access-denied__wrapper').hide();
    });

    $(document).on('click', '.pp-iframe__breadcrumbs-btn', function () {
      $('.pp-page').removeClass('js-iframe-page');
      $('.pp-container').show();
      $('.pp-iframe').hide();
      $('.pp-left-bar-btn').show();

      $('.pp-left-bar-btn').click();

      $('.pp-iframe__wrapper').html('');
    });

    // $(document).on('click', '.link-btn', function () {
    //   location.href = $(this).data('external-url');
    // });

    // $(document).on('contextmenu', '.link-btn', function (event) {
    //   if (event.which === 3) {
    //     event.preventDefault();

    //     if ($(this).data('outer-link') !== '#') {
    //       window.open($(this).data('outer-link'), '_blank');
    //     }
    //   }
    // });

    //Add info popup on hover
    infoPopup($('.info-block'));

    this.buildSidebarBottomLinks();

    $('body').prepend(`
    <style>
      .link-btn:hover svg path {
        fill: ${this.colors.mainActive};
      }

      .favorite-btn:hover svg path {
        fill: ${this.colors.mainActive};
      }

      .info-btn:hover svg path {
        fill: ${this.colors.mainActive};
      }
    </style>`);

    $('.dashboards__tab').each((i, item) => {
      $(item)
        .after()
        .css({
          content: `${$(item).data('tooltip-text')}`,
        });
    });

    if ($('.dashboards__tab').length == 1) {
      $('.dashboards__tab').css({
        border: '1px solid rgba(204, 207, 212, 0.6)',
        'border-radius': '3px',
      });
    } else if ($('.dashboards__tab').length >= 2) {
      $('body').prepend(`
        <style>

          .dashboards__tab:nth-child(2) {
            border-left: 1px solid transparent;
            border-right: 1px solid rgba(204, 207, 212, 0.6) !important;
            transform: translateX(-1px);
          }

          .dashboards__tab.js-tab-active:nth-child(2) {
            border-left: 1px solid transparent;
            border-right: 1px solid #20929E;
            transform: translateX(-1px);
          }

          .dashboards__tab:last-child {
            border-radius: 0 3px 3px 0;
            border-left: 1px solid rgba(204, 207, 212, 0.6);
          }
        </style>
      `);
    }
  }

  initSwitchersByVariables() {
    //If variable is 'Y' will enable button to swipe topbar
    if (this.enableTopbarHide === 'Y') {
      $('.top_menu_container').append(`
            <div class="top-wrap-btn" style="">&#x2191;</div>
          `);

      $('.top-wrap-btn').on('click', function () {
        $('.top_menu_container, body').toggleClass('wrapped-up-topbar');

        $('.pp-gradient').toggleClass('swipedTopbar')
      })
    }

    //If 'customTopbar' variable is 'Y' will enable custom styles from variable
    if (this.customTopbar === 'Y') {

      if (this.topbarBackgroundColor) {
        $('.top_menu').css({
          'background': this.topbarBackgroundColor,
        });

        $('.top_menu ul li').css({
          'border': 'none',
        });
      }

      //Set hover and highlighting for topbar
      if (this.topbarHighlightColor) {
        $('.top_menu .highlightCurrentPage').css({
          'background': `${this.topbarHighlightColor} !important`
        })

        $('body').prepend(`
              <style>
                .top_menu ul.mod_full-height-menu > li.active, 
                .top_menu ul.mod_full-height-menu > li:hover,
                .top_menu ul.mod_full-height-menu .highlightCurrentPage {
                  background: ${this.topbarHighlightColor} !important;
                }
      
                .top_menu .top-bar-dropdowns-menu li:hover {
                  background: ${this.topbarHighlightColor} !important;
                }
      
                .top_menu .main-search {
                  background: ${this.topbarHighlightColor} !important;
                }
    
                .top_menu > ul > li.active > ul, 
                .top_menu ul ul li.hovered > ul {
                  background: ${this.topbarHighlightColor};
                }
    
                .top_menu > ul > li.topMenuArrow.active {
                  background: ${this.topbarHighlightColor};
                }
              </style>
            `)
      }

      //Set topbar color for fonts and icons
      if (this.topbarColor) {
        $('.top_menu p, .top_menu span, .top_menu ul li, .top_menu b, .top_menu i').css({
          color: this.topbarColor,
          fill: this.topbarColor
        })

        $('.main-search__icon svg path').css({
          color: this.topbarColor,
          fill: this.topbarColor
        })

        $('body').prepend(`
              <style>
                .top_menu #globalSearchInput::placeholder {
                  color: ${this.topbarColor}
                }
              </style>
            `)
      }
    }

    //Set background color for PP
    if (this.portalPageBackground) {
      $('.pp-page').css({
        'background': `${this.portalPageBackground}`
      })
    }

    //If variable is not empty, change all title, links and 'mainActive' colored item to current color.
    if (this.mainPageColor) {
      //Transform hex to R G B to fill colors with opacity (alpha at rgba);
      const rgbFormat = hexToRgb(this.mainPageColor);

      $('.pp-page').prepend(`
            <style>
              input[type=text], 
              input[type=password] {
                color: ${this.mainPageColor} !important;
              }

              input[type=text]:focus {
                color: ${this.mainPageColor} !important;
                border-color: ${this.mainPageColor} !important;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(${rgbFormat.r},${rgbFormat.g},${rgbFormat.b}, 0.2) !important;
              }

              a,
              .announcements-link,
              .close-announce,
              .side-item__title-name,
              .dashboard-item__title,
              .announcement__read-more,
              .announcement__lower-title,
              .elements-breadcrumbs__item:not(:last-child) {
                color: ${this.mainPageColor};
              }

              .pp-left-bar-menu__title-arrow, 
              .pp-left-bar-menu__title-arrow path,
              .announcements-link__svg,
              .announcements-link__svg path,
              .pp-left-bar-btn-icon svg,
              .pp-left-bar-btn-icon svg path,
              .js-menu-title-icon__icon,
              .js-menu-title-icon__icon path {
                fill: ${this.mainPageColor};
              }

              .tile.js-active svg,
              .tile.js-active svg path,
              .list.js-active svg,
              .list.js-active svg path {
                fill: ${this.mainPageColor} !important;
              }
    
              .dashboards .tile.js-active,
              .dashboards .list.js-active {
                border: 1px solid ${this.mainPageColor};
                background: rgba(${rgbFormat.r},${rgbFormat.g},${rgbFormat.b}, 0.1);
              }
    
              .label_element_list.tags_list li {
                border: none;
                background: rgba(${rgbFormat.r},${rgbFormat.g},${rgbFormat.b}, 0.7);
              }
    
              .pp-access-denied__icon svg path {
                fill: ${this.mainPageColor};
              }
    
              .submit-popup {
                background: ${this.mainPageColor};
              }
    
              .submit-popup:hover {
                color: ${this.mainPageColor} !important;
                background: transparent !important;
                border: 1px solid ${this.mainPageColor} !important;
              }
    
              .pp-access-denied__main a {          
                color: ${this.mainPageColor} !important;
                text-decoration: underline !impoertant;
              }
    
              .cancel-popup:hover {
                background: ${this.mainPageColor} !important;
              }
    
              .dashboards__tab.js-tab-active {
                color: ${this.mainPageColor} !important;
                border-color: ${this.mainPageColor} !important;
                background: rgba(${rgbFormat.r},${rgbFormat.g},${rgbFormat.b}, 0.1);
              }
    
              .dashboard-item__tags-tag {
                color: ${this.mainPageColor} !important;
                background: rgba(${rgbFormat.r},${rgbFormat.g},${rgbFormat.b}, 0.12);
              }
    
              .announcements-link {
                color: ${this.mainPageColor} !important;
              }
    
              .pp-iframe__breadcrumbs-item {
                color: ${this.mainPageColor} !important;
              }

              .dashboards__tab:nth-child(2).js-tab-active {
                border: 1px solid ${this.mainPageColor};
              }

              .dashboards__tab.js-tab-active:nth-child(2) {
                border-right: 1px solid ${this.mainPageColor};
              }

              .pp-searchbar__icon svg path {
                fill: ${this.mainPageColor};
              }
            </style>
          `)
    }

    this.portalPageSearch();
  }

  portalPageSearch() {
    $('.pp-searchbar__input').on('input', function() {
      var searchText = $(this).val().toLowerCase(); // Get the typed text and convert it to lowercase

      console.log(searchText);
  
      // Loop through each element with the desired name attribute
      $('.dashboard-item').each(function() {
        var elementText = $(this).data('element-name').toLowerCase(); // Get the element's value and convert it to lowercase

        console.log(elementText);
  
        // Check if the element's value contains the typed text
        if (elementText.indexOf(searchText) !== -1) {
          // Element matches the filter, show it
          $(this).show();
        } else {
          // Element does not match the filter, hide it
          $(this).hide();
        }
      });
    });
  }

  trackDateOnClick(element) {
    const clickDateTime = new Date();
    let formattedDateTime =
      clickDateTime.getFullYear() +
      '-' +
      (clickDateTime.getMonth() + 1).toString().padStart(2, '0') +
      '-' +
      clickDateTime.getDate().toString().padStart(2, '0') +
      ' ' +
      clickDateTime.getHours().toString().padStart(2, '0') +
      ':' +
      clickDateTime.getMinutes().toString().padStart(2, '0') +
      ':' +
      clickDateTime.getSeconds().toString().padStart(2, '0');
    return formattedDateTime;
  }

  getFolderElements(folder) {
    return this.globalFullObject.filter((elem) => {
      if (Array.isArray(elem.folder_id)) {
        return elem.folder_id.includes(folder.folder_id);
      }

      return false;
    });
  }

  getFolderElementsDeep(folder) {
    const currentFolderElements = this.getFolderElements(folder);

    if (folder.childs) {
      for (const f of Object.values(folder.childs)) {
        currentFolderElements.push(...this.getFolderElementsDeep(f));
      }
    }
    return currentFolderElements;
  }

  getSubfolderElementsDeep(folder, acc = {}) {
    const subfolderElements = acc;

    const elements = this.getFolderElements(folder).filter(
      (el) => el.section_type == 'Category',
    );

    if (elements.length) {
      subfolderElements[folder.folder_id] = elements;
    }

    for (const sf of Object.values(folder.childs || {})) {
      this.getSubfolderElementsDeep(sf, acc);
    }

    return acc;
  }

  buildSidebarBottomLinks() {
    for (const sidebarLink of this.sidebarBottomLinks) {
      $('.pp-left-bar-bottom').append(`
        <a class="pp-left-bar-bottom__link" target="_blank" href="${sidebarLink['Sidebar Bottom Url']}">
          <img class="pp-left-bar-bottom__icon" src="${sidebarLink['Sidebar Bottom Icon']}"
            alt="external sidebar link" />
          <span class="pp-left-bar-bottom__text" ${sidebarLink['Text Style'] == 'Link' ? `style="color: ${this.mainPageColor}; text-decoration: underline"` : ''}>${sidebarLink['Sidebar Bottom Text']}</span>
        </a>
      `);
    }
  }

  buildSideItem(appendType, wrapper, element) {
    const self = this;
    const contentTypeLogo = getTileExternalIconHtml(element.content_type);
    let lastViewed = '';
    let formattedDate = '';

    const contentType = hashTable[element.element_type] || element.element_type;

    if (element.last_view_time != undefined) {
      lastViewed = element.last_view_time.split(' ')[0];
      let formatimgDate = formatDate(lastViewed);
      formattedDate = `Last Viewed ${formatimgDate}`;
    } else {
      formattedDate = '';
    }

    if (appendType === 'append') {
      $(wrapper).append(`
      <div class="side-item" data-access="${element.has_access}" data-segment="${element.segment_value_id}" data-info-id="${element.user_dashboard_element_instance_id}" data-info-id="${element.user_dashboard_element_instance_id}" data-element-id="${element.element_id}" data-element-name="${element.element_dashboard_name}">
        <div class="displayF">
          <div class="side-item__logo">
            ${contentTypeLogo}
          </div>
          <div class="side-item__title">
            <span class="side-item__title-name">
              ${element.element_dashboard_name}
            </span>
            <span class="side-item__title-date">
              ${formattedDate}
            </span>
          </div>
        </div>
        <div class="side-item__info">
          <div class="info-btn" data-info-id="${element.user_dashboard_element_instance_id}">
            <img src="/pt/simplify-catalog/assets/img/info.svg" alt="" />
          </div>
        </div>
      </div>
      `);
    } else if (appendType === 'prepend') {
      $(wrapper).prepend(`
      <div class="side-item" data-access="${element.has_access}" data-segment="${element.segment_value_id}" data-info-id="${element.user_dashboard_element_instance_id}" data-element-id="${element.element_id}" data-element-name="${element.element_dashboard_name}">
        <div class="displayF">
          <div class="side-item__logo">
            ${contentTypeLogo}
          </div>
          <div class="side-item__title">
            <span class="side-item__title-name">
              ${element.element_dashboard_name}
            </span>
            <span class="side-item__title-date">
              ${formattedDate}
            </span>
          </div>
        </div>
        <div class="side-item__info">
          <div class="info-btn" data-info-id="${element.user_dashboard_element_instance_id}">
            <img src="/pt/simplify-catalog/assets/img/info.svg" alt="" />
          </div>
        </div>
      </div>
      `);
    }
  }

  buildDeniePopup(wrapper, message) {
    wrapper.append(`
    <div class="pp-access-denied__wrapper">

      <div class="pp-access-denied">
        <div class="pp-access-denied__main">
          <div class="pp-access-denied__icon">
            <svg width="28" height="30" viewBox="0 0 28 30" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M10.2287 4.56226C11.2289 3.56207 12.5855 3.00016 14 3.00016C15.4145 3.00016 16.771 3.56207 17.7712 4.56226C18.7714 5.56245 19.3333 6.91901 19.3333 8.3335V12.3335H8.66664V8.3335C8.66664 6.91901 9.22854 5.56245 10.2287 4.56226ZM5.99997 12.3335V8.3335C5.99997 6.21176 6.84282 4.17693 8.34312 2.67664C9.84341 1.17635 11.8782 0.333496 14 0.333496C16.1217 0.333496 18.1565 1.17635 19.6568 2.67664C21.1571 4.17693 22 6.21176 22 8.3335V12.3335H23.3333C25.5424 12.3335 27.3333 14.1244 27.3333 16.3335V25.6668C27.3333 27.876 25.5424 29.6668 23.3333 29.6668H4.66663C2.45749 29.6668 0.666626 27.876 0.666626 25.6668V16.3335C0.666626 14.1244 2.45749 12.3335 4.66663 12.3335H5.99997ZM20.6666 15.0002H7.3333H4.66663C3.93025 15.0002 3.33329 15.5971 3.33329 16.3335V25.6668C3.33329 26.4032 3.93025 27.0002 4.66663 27.0002H23.3333C24.0697 27.0002 24.6666 26.4032 24.6666 25.6668V16.3335C24.6666 15.5971 24.0697 15.0002 23.3333 15.0002H20.6666Z" fill="#20929E"/>
            </svg>          
          </div>
          <div class="pp-access-denied__title">Request Access</div>
          <div class="pp-access-denied__descr">
            ${message}
          </div>
        </div>
        <div class="pp-access-denied__footer">
          <div id="pp-form" class="pp-access-denied__denied-form">
            <button class="cancel-popup">Cancel</button>
          </div>
        </div>
      </div>

    </div>
    `);
  }

  //Build Dashboard Item
  buildDashboardItem(wrapper, element, folderName) {
    const self = this;
    const contentTypeLogo = getTileExternalIconHtml(element.content_type);
    let lastViewed = '';
    let formattedDate = '';
    let thumbnail = '';
    let cuttedTitle = formatTitleText(element.element_dashboard_name, 21, 40);

    let certification = element.certified_ind;
    let certificationColor = !element.certification_level_color ? '#679823' : element.certification_level_color;
    let infoIcon = `<i class="fa mi-certified"></i>`;

    switch(certification) {
      case 'Y':
        infoIcon = `<i class="fa mi-certified" style="color: ${certificationColor}"></i>`;
        break;
      case 'N':
        infoIcon = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7 13C10.3137 13 13 10.3137 13 7C13 3.68629 10.3137 1 7 1C3.68629 1 1 3.68629 1 7C1 10.3137 3.68629 13 7 13ZM7 14C10.866 14 14 10.866 14 7C14 3.13401 10.866 0 7 0C3.13401 0 0 3.13401 0 7C0 10.866 3.13401 14 7 14ZM7 6C7.27614 6 7.5 6.22386 7.5 6.5V10.4062C7.5 10.6824 7.27614 10.9062 7 10.9062C6.72386 10.9062 6.5 10.6824 6.5 10.4062V6.5C6.5 6.22386 6.72386 6 7 6ZM7 3.5C6.72386 3.5 6.5 3.72386 6.5 4C6.5 4.27614 6.72386 4.5 7 4.5H7.00667C7.28281 4.5 7.50667 4.27614 7.50667 4C7.50667 3.72386 7.28281 3.5 7.00667 3.5H7Z" fill="#222222"/>
        </svg>
        `;
        break;
    }

    const contentType = hashTable[element.element_type] || element.element_type;

    if (!element.last_view_time) {
      lastViewed = '';
    } else {
      lastViewed = element.last_view_time.split(' ')[0];
      let formatimgDate = formatDate(lastViewed);
      formattedDate = getDayOfWeek(formatimgDate) + ` ${formatimgDate}`;
    }

    if (element.has_access === 'Y') {
      thumbnail = `<div class="lazy" data-loader="customLoaderName"></div>
      <img class="dashboard-item__thumbnail-img lazy"
                  src="/content/index/thumbnail/element/${element.element_id}/segment/${element.segment_value_id}"
                  alt="thumbnail"/>
                  <div class="lazy" data-loader="customLoaderName"></div>
      <div class="lazy" data-loader="asyncLoader"></div>`;
    } else {
      thumbnail = `
        <div class="locked-access">
          <svg width="20" height="22" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M7.17157 3.17157C7.92172 2.42143 8.93913 2 10 2C11.0609 2 12.0783 2.42143 12.8284 3.17157C13.5786 3.92172 14 4.93913 14 6V9H6V6C6 4.93913 6.42143 3.92172 7.17157 3.17157ZM4 9V6C4 4.4087 4.63214 2.88258 5.75736 1.75736C6.88258 0.632141 8.4087 0 10 0C11.5913 0 13.1174 0.632141 14.2426 1.75736C15.3679 2.88258 16 4.4087 16 6V9H17C18.6569 9 20 10.3431 20 12V19C20 20.6569 18.6569 22 17 22H3C1.34315 22 0 20.6569 0 19V12C0 10.3431 1.34315 9 3 9H4ZM15 11H5H3C2.44772 11 2 11.4477 2 12V19C2 19.5523 2.44772 20 3 20H17C17.5523 20 18 19.5523 18 19V12C18 11.4477 17.5523 11 17 11H15Z" fill="#222222" fill-opacity="0.64"/>
          </svg>
        </div>`;
    }

    let favoriteClass = '';
    let favoriteIcon = `
      <svg width="16" height="16" viewBox="0 0 16 16" fill-rule="evenodd" clip-rule="evenodd" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5158 6.11898C10.1921 6.07257 9.91152 5.87079 9.7645 5.57866L8 2.0727L6.2355 5.57866C6.08848 5.87079 5.80789 6.07257 5.48416 6.11898L1.54619 6.68351L4.38266 9.39312C4.62407 9.62374 4.73447 9.95961 4.67696 10.2885L4.00677 14.1209L7.5416 12.2977C7.8292 12.1494 8.1708 12.1494 8.4584 12.2977L11.9932 14.1209L11.323 10.2885C11.2655 9.95961 11.3759 9.62374 11.6173 9.39312L14.4538 6.68351L10.5158 6.11898ZM15.1434 6.02472L15.143 6.02511L15.1434 6.02472ZM8.41698 1.24417C8.41708 1.24398 8.41718 1.24378 8.41728 1.24358L8 1.03357L8.41728 1.24358L8.41698 1.24417ZM10.6577 5.1291L8.47597 0.794022C8.38521 0.613693 8.20116 0.5 8 0.5C7.79884 0.5 7.61479 0.613693 7.52403 0.794022L5.34225 5.1291L0.457996 5.82928C0.25561 5.85829 0.0875437 6.00096 0.0253202 6.19657C-0.0369032 6.39218 0.0176668 6.6063 0.165808 6.74781L3.69191 10.1162L2.86032 14.8716C2.82529 15.0719 2.9062 15.2749 3.06919 15.3955C3.23217 15.5162 3.44912 15.5337 3.62923 15.4408L8 13.1865L12.3708 15.4408C12.5509 15.5337 12.7678 15.5162 12.9308 15.3955C13.0938 15.2749 13.1747 15.0719 13.1397 14.8716L12.3081 10.1162L15.8342 6.74781C15.9823 6.6063 16.0369 6.39218 15.9747 6.19657C15.9125 6.00096 15.7444 5.85829 15.542 5.82928L10.6577 5.1291Z"/>
      </svg>`;

    if (!element.in_favorites) {
      favoriteClass = 'non-favorite';
    } else if (element.in_favorites && element.in_favorites.split(',').some((item) => item == this.favoritesFolder)) {
      favoriteClass = 'is-favorite';
      favoriteIcon = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g clip-path="url(#clip0_674_1924)">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.6577 5.1291L8.47597 0.794022C8.38521 0.613693 8.20116 0.5 8 0.5C7.79884 0.5 7.61479 0.613693 7.52403 0.794022L5.34225 5.1291L0.457996 5.82928C0.25561 5.85829 0.0875437 6.00096 0.0253202 6.19657C-0.0369032 6.39218 0.0176668 6.6063 0.165808 6.74781L3.69191 10.1162L2.86032 14.8716C2.82529 15.0719 2.9062 15.2749 3.06919 15.3955C3.23217 15.5162 3.44912 15.5337 3.62923 15.4408L8 13.1865L12.3708 15.4408C12.5509 15.5337 12.7678 15.5162 12.9308 15.3955C13.0938 15.2749 13.1747 15.0719 13.1397 14.8716L12.3081 10.1162L15.8342 6.74781C15.9823 6.6063 16.0369 6.39218 15.9747 6.19657C15.9125 6.00096 15.7444 5.85829 15.542 5.82928L10.6577 5.1291Z" fill="#FFB000"/>
          </g>
          <defs>
            <clipPath id="clip0_674_1924">
              <rect width="16" height="16" fill="white"/>
            </clipPath>
          </defs>
        </svg>`;
    } else {
      favoriteClass = '';
    }

    let favoriteButton = '';

    switch(element.has_access) {
      case 'Y':
        favoriteButton = `
        <div class="favorite-btn ${favoriteClass}" data-favorite-folder="${element.in_favorites}" data-element="${element.element_id}" data-segment="${element.segment_value_id}">
          ${favoriteIcon}
        </div>`;
        break;
      case 'N':
        favoriteButton = '';
    }


    //Get topics names
    // const tagsPromise = this.buildTag(element.topics);

    $(wrapper).append(`
      <div class="dashboard-item ${favoriteClass}" data-element-name="${element.element_dashboard_name}" data-access="${element.has_access}" data-info-id="${element.user_dashboard_element_instance_id}" data-element-id="${element.element_id}" data-segment-id="${element.segment_value_id}">
        <div class="dashboard-item__upper">

          <!-- Icons "Favorite", "Link", "Info" -->
          <div class="dashboard-item__upper-left">
            <div class="favorite-btn ${favoriteClass}" data-favorite-folder="${element.in_favorites}" data-element="${element.element_id}" data-segment="${element.segment_value_id}">
            ${favoriteButton}
            </div>
            
          </div>
          <div class="dashboard-item__upper-right">
            <a href="/${contentType}/index/index/element/${element.element_id}/segment/${element.segment_value_id}" target="_blank" class="link-btn">
              <svg width="16" height="16" viewBox="0 0 16 16" fill-rule="evenodd" clip-rule="evenodd" xmlns="http://www.w3.org/2000/svg">
                <g opacity="0.64">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5 1.5C10.5 1.77614 10.7239 2 11 2H13.2929L6.14645 9.14645C5.95118 9.34171 5.95118 9.65829 6.14645 9.85355C6.34171 10.0488 6.65829 10.0488 6.85355 9.85355L14 2.70711V5C14 5.27614 14.2239 5.5 14.5 5.5C14.7761 5.5 15 5.27614 15 5V1.5C15 1.22386 14.7761 1 14.5 1H11C10.7239 1 10.5 1.22386 10.5 1.5ZM6 4C6.27614 4 6.5 3.77614 6.5 3.5C6.5 3.22386 6.27614 3 6 3H2.83333C2.3471 3 1.88079 3.19315 1.53697 3.53697C1.19316 3.88079 1 4.3471 1 4.83333V8V13.1667C1 13.6529 1.19316 14.1192 1.53697 14.463C1.88079 14.8068 2.3471 15 2.83333 15H8H11.1667C11.6529 15 12.1192 14.8068 12.463 14.463C12.8068 14.1192 13 13.6529 13 13.1667V10C13 9.72386 12.7761 9.5 12.5 9.5C12.2239 9.5 12 9.72386 12 10V13.1667C12 13.3877 11.9122 13.5996 11.7559 13.7559C11.5996 13.9122 11.3877 14 11.1667 14H8H2.83333C2.61232 14 2.40036 13.9122 2.24408 13.7559C2.0878 13.5996 2 13.3877 2 13.1667L2 7.99949L2 4.83333C2 4.61232 2.0878 4.40036 2.24408 4.24408C2.40036 4.0878 2.61232 4 2.83333 4H6Z"/>
                </g>
              </svg>
            </a>

            <a href="/editor/${contentType}/edit/element/${element.element_id}" target="_blank" class="settings-btn">
              <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill-rule="evenodd" clip-rule="evenodd">
                <path d="M12 8.666c-1.838 0-3.333 1.496-3.333 3.334s1.495 3.333 3.333 3.333 3.333-1.495 3.333-3.333-1.495-3.334-3.333-3.334m0 7.667c-2.39 0-4.333-1.943-4.333-4.333s1.943-4.334 4.333-4.334 4.333 1.944 4.333 4.334c0 2.39-1.943 4.333-4.333 4.333m-1.193 6.667h2.386c.379-1.104.668-2.451 2.107-3.05 1.496-.617 2.666.196 3.635.672l1.686-1.688c-.508-1.047-1.266-2.199-.669-3.641.567-1.369 1.739-1.663 3.048-2.099v-2.388c-1.235-.421-2.471-.708-3.047-2.098-.572-1.38.057-2.395.669-3.643l-1.687-1.686c-1.117.547-2.221 1.257-3.642.668-1.374-.571-1.656-1.734-2.1-3.047h-2.386c-.424 1.231-.704 2.468-2.099 3.046-.365.153-.718.226-1.077.226-.843 0-1.539-.392-2.566-.893l-1.687 1.686c.574 1.175 1.251 2.237.669 3.643-.571 1.375-1.734 1.654-3.047 2.098v2.388c1.226.418 2.468.705 3.047 2.098.581 1.403-.075 2.432-.669 3.643l1.687 1.687c1.45-.725 2.355-1.204 3.642-.669 1.378.572 1.655 1.738 2.1 3.047m3.094 1h-3.803c-.681-1.918-.785-2.713-1.773-3.123-1.005-.419-1.731.132-3.466.952l-2.689-2.689c.873-1.837 1.367-2.465.953-3.465-.412-.991-1.192-1.087-3.123-1.773v-3.804c1.906-.678 2.712-.782 3.123-1.773.411-.991-.071-1.613-.953-3.466l2.689-2.688c1.741.828 2.466 1.365 3.465.953.992-.412 1.082-1.185 1.775-3.124h3.802c.682 1.918.788 2.714 1.774 3.123 1.001.416 1.709-.119 3.467-.952l2.687 2.688c-.878 1.847-1.361 2.477-.952 3.465.411.992 1.192 1.087 3.123 1.774v3.805c-1.906.677-2.713.782-3.124 1.773-.403.975.044 1.561.954 3.464l-2.688 2.689c-1.728-.82-2.467-1.37-3.456-.955-.988.41-1.08 1.146-1.785 3.126"/>
              </svg>
            </a>

            <div class="info-btn" data-info-id="${element.user_dashboard_element_instance_id}">
              ${infoIcon}
            </div>

          </div>
        </div>

        <div class="dashboard-item__main" data-type="${contentType}" data-element-id="${element.element_id}" data-segment="${element.segment_value_id}" data-info-id="${element.user_dashboard_element_instance_id}" data-element-name="${element.element_dashboard_name}">
          <div class="dashboard-item__title" style="color: ${this.elementTitleColor}">
            ${cuttedTitle}
          </div>

          <div class="dashboard-item__tags" data-topics="[${element.topics}]">
            <!-- Add tags/topics -->
          </div>
          
          <div class="dashboard-item__engagement">
            ${!element.total_view_count ? '' : element.total_view_count}
          </div>

          <div class="dashboard-item__last-view">
            ${formattedDate}
          </div>

          <div class="dashboard-item__details">
            <div class="dashboard-item__item-content-name">${element.content_type}</div>
            <div class="dashboard-item__logo">
              <!-- Content logo -->
              ${contentTypeLogo}
            </div>
          </div>
          
          <div class="dashboard-item__thumbnail">
              <!-- Thumbnail -->
              ${thumbnail}
            </div>

        </div>
      </div>
    `);
  }

  favoriteToggle(element, favoriteFolder) {
    const self = this;

    $(document).on('click', element, function () {
      const $this = $(this);

      if ($this.hasClass('non-favorite')) {
        $(`.favorite-btn[data-element="${$this.data('element')}"][data-segment="${$this.data('segment')}"]`).removeClass(
          'non-favorite',
        );
        $(`.favorite-btn[data-element="${$this.data('element')}"][data-segment="${$this.data('segment')}"]`).addClass(
          'is-favorite',
        );

        for (const el of self.globalFullObject) {
          if ($this.data('element') == el.element_id && $this.data('segment') == el.segment_value_id) {
            el.in_favorites = favoriteFolder;
          }
        }

        self.addToFavorite(
          favoriteFolder,
          $this.data('element'),
          $this.data('segment'),
        );
      } else if ($this.hasClass('is-favorite')) {
        $(`.favorite-btn[data-element="${$this.data('element')}"][data-segment="${$this.data('segment')}"]`).removeClass(
          'is-favorite',
        );
        $(`.favorite-btn[data-element="${$this.data('element')}"][data-segment="${$this.data('segment')}"]`).addClass(
          'non-favorite',
        );

        for (const el of self.globalFullObject) {
          if ($this.data('element') == el.element_id && $this.data('segment') == el.segment_value_id) {
            el.in_favorites = null;
          }
        }

        self.deleteFromFavorite(
          favoriteFolder,
          $this.data('element'),
          $this.data('segment'),
        );
      }
    });
  }

  // Get all of the folders from the instance
  async fetchTopics(topicId) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: '/api/topic/id/' + topicId,
        type: 'GET',
        dataType: 'json',
        success: resolve,
        error: reject,
      });
    });
  }

  // Get Announcement
  fetchAnnouncement() {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: '/api/announcement?all=Y',
        type: 'GET',
        dataType: 'json',
        success: resolve,
        error: reject,
      });
    });
  }

  addToFavorite(favoriteFolderId, elementId, elementSegment) {
    const self = this;
    return $.ajax({
      url: `/api/favorite_element`,
      type: 'POST',
      data: `favorite_id=${favoriteFolderId}&element_id=${elementId}&segment_value_id=${elementSegment}`,
      success: function () {
        $(`.favorite-btn[data-element="${elementId}"][data-segment="${elementSegment}"]`).html(`
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_674_1924)">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.6577 5.1291L8.47597 0.794022C8.38521 0.613693 8.20116 0.5 8 0.5C7.79884 0.5 7.61479 0.613693 7.52403 0.794022L5.34225 5.1291L0.457996 5.82928C0.25561 5.85829 0.0875437 6.00096 0.0253202 6.19657C-0.0369032 6.39218 0.0176668 6.6063 0.165808 6.74781L3.69191 10.1162L2.86032 14.8716C2.82529 15.0719 2.9062 15.2749 3.06919 15.3955C3.23217 15.5162 3.44912 15.5337 3.62923 15.4408L8 13.1865L12.3708 15.4408C12.5509 15.5337 12.7678 15.5162 12.9308 15.3955C13.0938 15.2749 13.1747 15.0719 13.1397 14.8716L12.3081 10.1162L15.8342 6.74781C15.9823 6.6063 16.0369 6.39218 15.9747 6.19657C15.9125 6.00096 15.7444 5.85829 15.542 5.82928L10.6577 5.1291Z" fill="#FFB000"/>
            </g>
            <defs>
            <clipPath id="clip0_674_1924">
            <rect width="16" height="16" fill="white"/>
            </clipPath>
            </defs>
          </svg>

        `);

        for (const elemObj of self.globalFullObject) {
          if (elementId == elemObj.element_id &&
            elementSegment == elemObj.segment_value_id) {
            self.buildSideItem('prepend', $('.favorites__main'), elemObj);
            break;
          }
        }
      },
    });
  }

  deleteFromFavorite(favoriteFolderId, elementId, elementSegment) {
    return $.ajax({
      url: `/api/favorite_element?favorite_id=${favoriteFolderId}&id=${elementId}&segment_value_id=${elementSegment}`,
      type: 'DELETE',
      success: () => {
        $(`.favorite-btn[data-element="${elementId}"][data-segment="${elementSegment}"]`).html(`
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M10.5158 6.11898C10.1921 6.07257 9.91152 5.87079 9.7645 5.57866L8 2.0727L6.2355 5.57866C6.08848 5.87079 5.80789 6.07257 5.48416 6.11898L1.54619 6.68351L4.38266 9.39312C4.62407 9.62374 4.73447 9.95961 4.67696 10.2885L4.00677 14.1209L7.5416 12.2977C7.8292 12.1494 8.1708 12.1494 8.4584 12.2977L11.9932 14.1209L11.323 10.2885C11.2655 9.95961 11.3759 9.62374 11.6173 9.39312L14.4538 6.68351L10.5158 6.11898ZM15.1434 6.02472L15.143 6.02511L15.1434 6.02472ZM8.41698 1.24417C8.41708 1.24398 8.41718 1.24378 8.41728 1.24358L8 1.03357L8.41728 1.24358L8.41698 1.24417ZM10.6577 5.1291L8.47597 0.794022C8.38521 0.613693 8.20116 0.5 8 0.5C7.79884 0.5 7.61479 0.613693 7.52403 0.794022L5.34225 5.1291L0.457996 5.82928C0.25561 5.85829 0.0875437 6.00096 0.0253202 6.19657C-0.0369032 6.39218 0.0176668 6.6063 0.165808 6.74781L3.69191 10.1162L2.86032 14.8716C2.82529 15.0719 2.9062 15.2749 3.06919 15.3955C3.23217 15.5162 3.44912 15.5337 3.62923 15.4408L8 13.1865L12.3708 15.4408C12.5509 15.5337 12.7678 15.5162 12.9308 15.3955C13.0938 15.2749 13.1747 15.0719 13.1397 14.8716L12.3081 10.1162L15.8342 6.74781C15.9823 6.6063 16.0369 6.39218 15.9747 6.19657C15.9125 6.00096 15.7444 5.85829 15.542 5.82928L10.6577 5.1291Z"
                        fill="#222222"/>
            </svg>
        `);

        $(`.favorites__main .side-item[data-element-id="${elementId}"][data-segment="${elementSegment}"]`).remove();
      },
    });
  }

  async recentlyViewedItems() {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: '/api/element_views',
        type: 'GET',
        dataType: 'json',
        success: resolve,
        error: reject,
      });
    });
  }

  async getUser() {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: `/index/index/user-info`,
        type: 'GET',
        dataType: 'json',
        success: resolve,
        error: reject,
      });
    });
  }

  getFavorite() {
    return new Promise((resolve, reject) => {
      $.ajax({
        type: 'GET',
        url: '/api/favorite',
        dataType: 'JSON',
        success: resolve,
        error: reject,
      });
    });
  }

  addEntities(entity, data, id) {
    return $.ajax({
      url: `/data/page/${this.pageInternalName}/${entity}`,
      type: 'POST',
      dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      data: JSON.stringify({
        id: id,
        value: data,
      }),
    });
  }

  getEntities(entity) {
    return $.ajax({
      url: `/data/page/${this.pageInternalName}/${entity}`,
      type: 'GET',
      async: false,
    }).then((response) => {
      return response.data;
    });
  }

  updateEntity(entity, data, id) {
    return $.ajax({
      url: `/data/page/${this.pageInternalName}/${entity}?id=${id}`,
      type: 'PUT',
      dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      data: JSON.stringify(data),
    });
  }

  getElementInfo(id) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: `/api/element_info?element=${id}`,
        type: 'GET',
        dataType: 'json',
        success: resolve,
        error: reject,
      });
    });
  }
}
