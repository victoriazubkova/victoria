class NavigationBar {
  constructor(props) {
    // Main properties to manipulate and manage logic

    // Variables
    this.folders = props.folders;
    this.folderIdVariable = props.folderIdVariable;

    // Arrays of data
    this.elTypeRestrictions = props.elTypeRestrictions;
    this.favoriteFolderArray = props.favoriteFolderArray;

    // Boolean & Numeric
    this.navWidth = props.navWidth;
    this.hasHomeBtn = props.hasHomeBtn;
    this.hasNavHomeBtn = props.hasNavHomeBtn;
    this.hideNavBtnOnOpenedState = props.hideNavBtnOnOpenedState;
    this.activeOnClick = props.activeOnClick;

    // String
    this.homeBtnText = props.homeBtnText;
    this.navItemActiveColor = props.navItemActiveColor;
    this.navItemActiveBg = props.navItemActiveBg;

    // Function
    this.homeButtonClick = props.homeButtonClick;
    this.initCallback = props.initCallback;

    // Global colors variable
    this.colors = colorsFT;
    this.mainPageColor = props.mainPageColor;

    // Controls, dom elements
    this.$navWrapper = $('#pp-left-bar');
    this.$navToggleWrapper = $('#pp-left-bar-btn');
    this.$navTopControls = $('#pp-left-bar-controls');
    this.$navToggleIcon = $('#pp-left-bar-btn-icon');
    this.$navMenuWrapper = $('#pp-left-bar-menu-wrapper');

    // Predefined arrays for managing folders and fetched data
    this.globalFodlersArray = [];
    this.loadedElements = [];
    this.loadedFolderItems = [];
    this.loadedFoldersData = [];

    this.globalfolder = this.globalFodlersArray;

    this.initResolve; 
    this.inited = new Promise(resolve => this.initResolve = resolve);
  }

  init() {
    const self = this;
    const requests = [self.loadElementsData(), self.loadFolders()];

    Promise.all(requests).then(() => {
      self.getData(self.loadedFolderItems, self.loadedFoldersData);
      self.fillFavoritesArray();
      self.filterUserFolders();

      // self.hasHomeBtn && self.setNavTogglerHomeBtn();
      // self.hasNavHomeBtn && self.setNavHomeBtn();
      self.setNavCloseBtn();
      self.setNavWidth();
      self.setStyles();

      self.folders.forEach((folder) => {
        const {
          ['Default for Group Id']: defaultGroupId,
          Icon: icon,
          [self.folderIdVariable]: folderId,
        } = folder;

        self.buildNavSection({ defaultGroupId, icon, folderId });
      });

      self.initNavAccordion();
      self.handleEvents();

      self.initCallback();

      //Calculate height of content block in sidebar (between logo and bottom links)
      $('.pp-left-bar-content').css({
        'max-height': `calc(100vh - 40px - 5px - 159px - ${$('.pp-left-bar-bottom').outerHeight() + 5}px)`
      })

      this.initResolve(true);
    });
  }

  // Get elements & their correlation to folders as folder items
  loadElementsData = () => {
    const self = this;
    return new Promise((resolve) => {
      $.ajax({
        url: '/home/index/refresh/ajax/Y',
        type: 'POST',
        data: {
          folder_items: 'Y',
          all_folders: 'Y',
        },
        success: (res) => {
          resolve(
            (self.loadedElements = new DashboardStorage(res.data).rows),
            (self.loadedFolderItems = res.folderItems),
          );
        },
      });
    });
  };

  // Get all of the folders from the instance
  loadFolders = () => {
    const self = this;
    return new Promise((resolve) => {
      $.ajax({
        url: '/api/folder',
        type: 'GET',
        dataType: 'json',
        success: (res) => {
          resolve((self.loadedFoldersData = res.folders));
        },
      });
    });
  };

  // Main function of building main folders array, hierarchy etc
  getData = (folders, foldersData) => {
    let elementLinks = {};

    // Loop through elements and create elementLinks obj (pair id and element)
    for (const item in this.loadedElements) {
      if (this.loadedElements[item]['favorite_id'] == 0) {
        elementLinks[
          `${this.loadedElements[item]['element_id']}_${this.loadedElements[item]['segment_value_id']}`
        ] = this.loadedElements[item];
      }
    }

    for (const item of foldersData) {
      const folderObj = {
        id: item.folder_id,
        name: item.name,
        elements: [],
        parent_folder_id: item.parent_folder_id,
        childs: [],
      };

      this.globalFodlersArray.push(folderObj);
    }

    // Adding elements & pasting childs
    for (const item of folders) {
      if (
        undefined == elementLinks[`${item.element_id}_${item.segment_value_id}`]
      ) {
        continue;
      }

      const folderId = item.folder_id;
      const elementId = `${item.element_id}_${item.segment_value_id}`;
      const displayOrder = item.display_order;
      let elObj = {
        element: elementLinks[elementId],
        display_order: displayOrder,
      };

      for (const folder of this.globalFodlersArray) {
        const parentFolder = folder.parent_folder_id;
        const matchingArr = this.globalFodlersArray.filter(
          (folder) => folder.id == parentFolder,
        );

        if (folderId == folder.id) {
          folder.elements.push(elObj);
        }

        if (matchingArr.length > 0) {
          matchingArr[0]['childs'].push(folder);
        }
      }
    }

    // Sort & remove duplicates of folders childs
    for (const folder of this.globalFodlersArray) {
      folder.elements.sort((a, b) =>
        a.element.element_dashboard_name.localeCompare(
          b.element.element_dashboard_name,
        ),
      );
      folder.childs = this.removeDuplicateObjects(folder.childs, 'id');
    }

    // Setting folders tree
    const foldersMap = new Map(
      this.globalFodlersArray.map((folder) => [folder.id, folder]),
    );
    let foldersTree = [];

    this.globalFodlersArray.forEach((folder) => {
      if (foldersMap.has(folder.id)) {
        foldersTree.push(this.setFoldersHierarchy(folder, foldersMap));
      }
    });

    this.globalFodlersArray = foldersTree;
  };

  // Clean duplicates inside array
  removeDuplicateObjects = (array, key) => {
    const set = new Set();

    return array.filter((item) => {
      const alreadyHas = set.has(item[key]);
      set.add(item[key]);

      return !alreadyHas;
    });
  };

  // Set the folders hierarchy
  setFoldersHierarchy = (folder, map) => {
    if (folder !== undefined) {
      map.delete(folder.id);
      return folder.childs.length
        ? {
            id: folder.id,
            name: folder.name,
            elements: folder.elements,
            parent_folder_id: folder.parent_folder_id,
            childs: folder.childs.map((c) =>
              this.setFoldersHierarchy(map.get(c.id), map),
            ),
          }
        : folder;
    }
  };

  // Fill array of favorite items
  fillFavoritesArray = () => {
    for (const folder of this.favoriteFolderArray) {
      for (const item in this.loadedElements) {
        if (this.loadedElements[item]['favorite_id'] != 0) {
          folder.elements.push({
            element: this.loadedElements[item],
          });
        }
      }
    }

    for (const folder of this.favoriteFolderArray) {
      folder.elements.sort((a, b) =>
        a.element.element_dashboard_name.localeCompare(
          b.element.element_dashboard_name,
        ),
      );
    }
  };

  // Filter folders so show only those user needs
  filterUserFolders = () => {
    let filteredArray = [];

    this.folders.forEach((folder) => {
      const matchedFolder = this.findFolder(
        this.globalFodlersArray,
        folder[this.folderIdVariable],
      );

      if (matchedFolder !== undefined) {
        matchedFolder.parent_folder_id = undefined;
        filteredArray.push(matchedFolder);
      }
    });

    this.globalFodlersArray = filteredArray;

    console.log(this.globalFodlersArray);
  };

  // Helper recursive function for filtering user folders
  findFolder = (folders, id) => {
    let result;

    folders.some((folder) => {
      if (folder && folder.id === id) {
        result = folder;
        return true;
      } else if (folder && folder.childs) {
        result = this.findFolder(folder.childs, id);
        return result !== undefined;
      }
    });
  
    return result;
  };

  // Create separate section for parent folders
  buildNavSection = ({
    icon,
    folderId,
    defaultGroupId,
    customElId,
    isFavorite,
  }) => {
    const $menuSectionWrapper = $(
      `<div class="pp-left-bar-menu js-menu" ${
        customElId ? `id="${customElId}"` : ''
      } folder="${folderId}"></div>`,
    );

    if (isFavorite) {
      this.buildNav({
        icon,
        folders: this.favoriteFolderArray,
        wrapper: $menuSectionWrapper,
        defaultGroupId,
      });
    } else {
      this.buildNav({
        icon,
        folders: this.globalFodlersArray.filter(
          (folder) => folder.id == folderId,
        ),
        wrapper: $menuSectionWrapper,
        defaultGroupId,
      });
    }
  };

  // Create navigation list with title
  buildNavList = ({icon, folder, wrapper, defaultGroupId}) => {
    let elementsArray = [];

    for (const key of folder.elements) {
      for (const objKey in key) {
        elementsArray.push(key['element'].element_id);
      }
    }
    let uniqueElement = [...new Set(elementsArray)];

    const self = this;
    const $menuNavList = $(
      `<div class="pp-left-bar-menu__list ${
        folder.parent_folder_id !== undefined ? 'is-nested' : 'is-parent'
      } js-menu-list" data-nav-folder="${folder.id}"></div>`,
    );
    const $menuNavTitle =
      $(`<div class="pp-left-bar-menu__title js-menu-title p-main-color-text" data-nav-folder-id="${folder.id}" data-folder-name="${folder.name}" data-default-group-id="[${defaultGroupId}]" data-elements="[${uniqueElement}]">
                              <div class="pp-left-bar-menu__title-icon js-menu-title-icon">
                                ${
                                  folder.parent_folder_id !== undefined
                                    ? `<svg class="js-menu-title-icon__icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M1.24408 3.24408C1.40036 3.0878 1.61232 3 1.83333 3H4.89908L6.08397 4.77735C6.17671 4.91645 6.33282 5 6.5 5H13.1667C13.3877 5 13.5996 5.0878 13.7559 5.24408C13.9122 5.40036 14 5.61232 14 5.83333V13.1667C14 13.3877 13.9122 13.5996 13.7559 13.7559C13.5996 13.9122 13.3877 14 13.1667 14H1.83333C1.61232 14 1.40036 13.9122 1.24408 13.7559C1.0878 13.5996 1 13.3877 1 13.1667V3.83333C1 3.61232 1.0878 3.40036 1.24408 3.24408ZM1.83333 2C1.3471 2 0.880788 2.19315 0.536971 2.53697C0.193154 2.88079 0 3.3471 0 3.83333V13.1667C0 13.6529 0.193154 14.1192 0.536971 14.463C0.880787 14.8068 1.3471 15 1.83333 15H13.1667C13.6529 15 14.1192 14.8068 14.463 14.463C14.8068 14.1192 15 13.6529 15 13.1667V5.83333C15 5.3471 14.8068 4.88079 14.463 4.53697C14.1192 4.19315 13.6529 4 13.1667 4H6.76759L5.58269 2.22265C5.48996 2.08355 5.33384 2 5.16667 2H1.83333Z" fill="#20929E"/>
                                    </svg>`
                                    : `${icon ? `<img class="js-menu-title-icon__icon" src="${icon}" alt="${folder.name}">` : '' }`
                                }
                              </div>
                              ${folder.name}
                              <svg class="pp-left-bar-menu__title-arrow" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M9.85355 3.64645C10.0488 3.84171 10.0488 4.15829 9.85355 4.35355L6.20711 8L9.85355 11.6464C10.0488 11.8417 10.0488 12.1583 9.85355 12.3536C9.65829 12.5488 9.34171 12.5488 9.14645 12.3536L5.14645 8.35355C4.95118 8.15829 4.95118 7.84171 5.14645 7.64645L9.14645 3.64645C9.34171 3.45118 9.65829 3.45118 9.85355 3.64645Z" fill="#20929E"/>
                              </svg>

                          </div>`);

    for (let item of folder.elements) {
      if (
        !self.elTypeRestrictions.includes(item.element['element_type']) ||
        item.element['has_access'] == 'N'
      ) {
        continue;
      }

      // this.buildNavItem(item, $(menuNavList));
    }

    // Check wether passing folder has parent folder (meaning it is a child)
    if (folder.parent_folder_id !== undefined) {
      $(`[data-nav-folder="${folder.parent_folder_id}"]`).append($menuNavTitle);
      $(`[data-nav-folder="${folder.parent_folder_id}"]`).append($menuNavList);
    } else {
      wrapper.append($menuNavTitle);
      wrapper.append($menuNavList);
      this.$navMenuWrapper.append(wrapper);
    }
  };

  // Create navigation recursion (to create nesting)
  buildNav = ({icon, folders, wrapper, defaultGroupId}) => {
    folders.forEach((folder) => {
      if(folder) {
        this.buildNavList({icon, folder, wrapper, defaultGroupId});

        if (folder.childs && folder.childs.length) {
          this.buildNav({icon: '', folders: folder.childs, wrapper, defaultGroupId});
        }
      }
      
    });
  };

  // Home navigation button inside bar button
  setNavTogglerHomeBtn = () => {
    const homeBtn = `<div id="pp-left-bar-btn-home" class="pp-left-bar-btn__home js-home-bar-btn"><i class="fa fa-home"></i></div>`;
    this.$navToggleWrapper.prepend(homeBtn);
  };

  // Custom opened state
  toggleOpenedState = () => {
    $('.pp-page').toggleClass('js-sidebar-opened');

    this.$navWrapper.toggleClass('open');
    this.$navToggleWrapper.toggleClass('open');
    this.$navToggleWrapper.hasClass('open')
      ? this.$navToggleWrapper.css('left', `${this.navWidth}px`)
      : this.$navToggleWrapper.css('left', `0`);

    if (
      this.$navToggleWrapper.hasClass('open') &&
      this.hideNavBtnOnOpenedState
    ) {
      this.$navToggleWrapper.hide();
    } else {
      this.$navToggleWrapper.show();
    }
  };

  // Home navigation button inside navbar
  setNavHomeBtn = () => {
    const navHomeBtn = $(
      `<div class="pp-left-bar__home js-home-btn p-main-color-text"><i class="fa fa-home"></i>${this.homeBtnText}</div>`,
    );
    this.$navTopControls.prepend(navHomeBtn);
  };

  // Close button inside the navbar
  setNavCloseBtn = () => {
    const navCloseBtn = $(
      `<div class="pp-left-bar__close js-menu-close-btn">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M0.646447 0.646447C0.841709 0.451185 1.15829 0.451185 1.35355 0.646447L4.17678 3.46967L6 5.29289L10.6464 0.646447C10.8417 0.451184 11.1583 0.451184 11.3536 0.646447C11.5488 0.841709 11.5488 1.15829 11.3536 1.35355L6.70711 6L11.3536 10.6464C11.5488 10.8417 11.5488 11.1583 11.3536 11.3536C11.1583 11.5488 10.8417 11.5488 10.6464 11.3536L6 6.70711L1.35355 11.3536C1.15829 11.5488 0.841709 11.5488 0.646447 11.3536C0.451185 11.1583 0.451185 10.8417 0.646447 10.6464L5.29289 6L0.646447 1.35355C0.451184 1.15829 0.451184 0.841709 0.646447 0.646447Z" fill="#222222"/>
        </svg>
      </div>`,
    );
    this.$navTopControls.prepend(navCloseBtn);
  };

  // Navigation width defining with the props
  setNavWidth = () => {
    this.$navWrapper.css('width', this.navWidth);
  };

  // Accordions initialization
  initNavAccordion = () => {
    $('.js-menu-list').css('max-height', '0');
    $('.js-menu-title').removeClass('active');

    $('.js-menu-title').on('click', (e) => {
      let $target = $(e.currentTarget);
      let $menu = $target.next();
      let $menuTitle = $menu.prev();

      $target.toggleClass('active');

      if ($menu.height() != 0) {
        $menu.css('max-height', 0);
      } else {
        $menu.css('max-height', '100%');
      }
      
      $('.js-menu-title').removeClass('js-active-tab');
      $(`.js-menu-title[data-folder-name="${$target.data('folder-name')}"]`).addClass('js-active-tab')

      if (!$menu.hasClass('is-nested')) {
        $('.js-menu-list').not($menu).css('max-height', 0);
        $('.js-menu-title').not($target).removeClass('active');
      } else {
        if ($target.hasClass('active')) {
          $target
            .find('.js-menu-title-icon i')
            .addClass('fa-folder-open')
            .removeClass('fa-folder');
        } else {
          $target
            .find('.js-menu-title-icon i')
            .addClass('fa-folder')
            .removeClass('fa-folder-open');
        }

        while ($menu.hasClass('js-menu-list')) {
          $menu = $($menu).parent();
          $menuTitle = $menu.prev();
          $menu.css('max-height', '100%');
          if ($menu.hasClass('is-parent') || $menu.hasClass('is-nested')) {
            $menuTitle.addClass('active');
            $menu.hasClass('is-nested')
              ? $menuTitle
                  .find('.js-menu-title-icon i')
                  .addClass('fa-folder-open')
                  .removeClass('fa-folder')
              : '';
          }
        }
      }
    });
  };

  // Closing function for the accordions
  closeNavAccordions = () => {
    $('.js-menu-list').css('max-height', '0');
    $('.js-menu-title').removeClass('active');
    $('.js-menu-item').removeClass('active');

    $('.js-menu-list').each(function () {
      if ($(this).hasClass('is-nested')) {
        $(this).prev().find('img').attr('src', this.defaultFolderIcon);
      }
    });
  };

  // Some CSS styles
  setStyles = () => {
    const styles = `<style>
      .js-menu-item:hover,
      .js-menu-title:hover,
      .js-menu-item.active {
          color: ${this.navItemActiveColor};
          background: ${this.navItemActiveBg};
      }

      .js-menu-title:before,
      .js-menu-item:before {
        background: #eeeeee;
      }

      #pp-left-bar-btn,
      #pp-left-bar {
        background: ${this.colors.mainBackground};
      }

      .pp-left-bar-menu__title {
        color: ${this.mainPageColor}
      }

      .pp-left-bar-menu__title.js-active-tab {
        background: ${this.mainPageColor};
        color: #FFFFFF;
      }

      .js-menu-title.js-active-tab .pp-left-bar-menu__title-arrow path {
        fill: #FFFFFF;
      }

      .js-home-bar-btn,
      .js-home-btn {
        border-bottom-color: ${this.colors.mainBorders} !important;
      }

      .js-left-bar-content::-webkit-scrollbar-track {
        background: ${this.colors.mainBorders};
      }

      .js-left-bar-content::-webkit-scrollbar-thumb {
        background: ${this.colors.mainText};
      }
      </style>`;

    this.$navWrapper.append(styles);
  };

  // DOM Events
  handleEvents = () => {
    const self = this;

    // if(typeof state.sidebarOpen === 'undefined' || !state.sidebarOpen) {

    //   console.log(state)
    //   this.$navToggleIcon.on('click', () => {
    //     this.toggleOpenedState();
    //   });
    // }

    if(typeof state?.sidebarOpen === 'undefined' || state.sidebarOpen) {
      this.toggleOpenedState();
    }

    // Click on navigation toggle arrow
    this.$navToggleWrapper.on('click', () => {
      this.toggleOpenedState();
      state.sidebarOpen = true;
    });

    // Click on home buttons
    $(document).on('click', '.js-home-btn, .js-home-bar-btn', () => {
      this.closeNavAccordions();
      this.homeButtonClick();
    });

    // Click on close button
    $(document).on('click', '.js-menu-close-btn', () => {
      this.toggleOpenedState();
      state.sidebarOpen = false;
    });

    // Click on menu item
    $(document).on('click', '.js-menu-item', function () {
      if (self.activeOnClick) {
        $(this).addClass('active');
        $('.js-menu-item').not($(this)).removeClass('active');
      }
    });
  };
}
