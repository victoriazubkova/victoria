/**
 * @typedef {'left'|'top'|'right'|'bottom'} ConnectDirection
 */

class FlowChart {
  /**
   * @type {import('fabric/fabric-impl').Object[]}
   */
  nodes;
  /**
   * @type {import('fabric/fabric-impl').Object[]}
   */
  customNodes;
  /**
   * @type {Promise<import('fabric/fabric-impl').Object>[]}
   */
  nodePromises;
  /**
   * @type {import('fabric/fabric-impl').Object[]}
   */
  edges;
  /**
   * @type {{ start: string|{x: number; y: number;}; end: string|{ x: number; y: number; }, opts: any }[]}
   */
  rawEdges;
  /**
   * @type {import('fabric/fabric-impl').Canvas}
   */
  canvas;

  GRID_WIDTH = 192;
  GRID_WIDTH_SPACING = 152;
  GRID_HEIGHT = 152;
  GRID_HEIGHT_SPACING = 40;

  EDGE_POSITIONS_COUNT = 11;
  EDGE_OFFSET_RANGE = 0.7;
  EDGE_PADDING = 15;
  MIN_PART_EDGE_LENGTH = 30;

  LINE_ROUND = 15;

  /**
   * @param {import('fabric/fabric-impl').Canvas} canvas
   */
  constructor(canvas) {
    this.nodes = [...FlowChart.#getInitNodes()];
    this.customNodes = [];
    this.nodePromises = [];
    this.edges = [];
    this.rawEdges = [];

    this.canvas = canvas;
  }

  /**
   * @param {number} width
   * @param {number} height
   */
  setGrid(width, height) {
    this.GRID_WIDTH = width;
    this.GRID_HEIGHT = height;
  }

  /**
   * @param {number} width
   * @param {number} height
   */
  setGridSpacing(width, height) {
    this.GRID_WIDTH_SPACING = width;
    this.GRID_HEIGHT_SPACING = height;
  }

  /**
   * @param {string} url
   * @return {Promise<import('fabric/fabric-impl').Image>}
   */
  static async imageFromUrl(url) {
    return await new Promise((resolve) => {
      fabric.Image.fromURL(url, resolve);
    });
  }

  static #getInitNodes() {
    return [
      // zero point node
      new fabric.Group([], { left: 0, top: 0 }),
    ];
  }

  /**
   * @param {number} x
   * @param {number} y
   * @return {{top: number, left: number}}
   */
  getPosition(x, y) {
    return {
      left: (this.GRID_WIDTH + this.GRID_WIDTH_SPACING) * x,
      top: (this.GRID_HEIGHT + this.GRID_HEIGHT_SPACING) * y,
    };
  }

  /**
   * @param {number} left
   * @param {number} top
   * @return {{x: number, y: number}}
   */
  getCoords(left, top) {
    return {
      x: left / (this.GRID_WIDTH + this.GRID_WIDTH_SPACING),
      y: top / (this.GRID_HEIGHT + this.GRID_HEIGHT_SPACING),
    };
  }

  /**
   * Round number to `precision` numbers after coma
   *
   * @param {number} n
   * @param {number} precision
   * @return {number}
   */
  static #roundToPrecision(n, precision) {
    const p = Math.pow(10, precision);

    return Math.round(n * p) / p;
  }

  /**
   * Check if points on the same line
   *
   * @param {number} x1
   * @param {number} y1
   * @param {number} x2
   * @param {number} y2
   * @return {boolean}
   */
  static #isOnSameLine(x1, y1, x2, y2) {
    const precision = 5;

    return (
      this.#roundToPrecision(x1, precision) ===
        this.#roundToPrecision(x2, precision) ||
      this.#roundToPrecision(y1, precision) ===
        this.#roundToPrecision(y2, precision)
    );
  }

  /**
   * @param {number} cx Center point X
   * @param {number} cy Center point Y
   * @param {number} x Vector point X
   * @param {number} y Vector point Y
   * @return {ConnectDirection}
   */
  static #getConnectDirection(cx, cy, x, y) {
    let dir = (Math.atan2(y - cy, x - cx) * 180) / Math.PI;

    if (dir === 45 || dir === 135 || dir === -135 || dir === -45) {
      dir += Math.random() > 0.5 ? 0.5 : -0.5;
    }

    if (dir > -45 && dir < 45) {
      return 'right';
    } else if (dir > 45 && dir < 135) {
      return 'bottom';
    } else if (dir > 135 || (dir >= -180 && dir < -135)) {
      return 'left';
    } else if (dir > -135 && dir < -45) {
      return 'top';
    }
  }

  /**
   * @param {number} l1x1 Line1 X1
   * @param {number} l1y1 Line1 Y1
   * @param {number} l1x2 Line1 X2
   * @param {number} l1y2 Line1 Y2
   * @param {number} l2x1 Line2 X1
   * @param {number} l2y1 Line2 Y1
   * @param {number} l2x2 Line2 X2
   * @param {number} l2y2 Line2 Y2
   * @return {boolean}
   */
  static #isLinesIntersect(l1x1, l1y1, l1x2, l1y2, l2x1, l2y1, l2x2, l2y2) {
    let x;
    let y;

    // Line 1 or Line 2 parallel to Y-axis
    if (l1x1 === l1x2 || l2x1 === l2x2) {
      if (l1x1 === l1x2 && l2x1 === l2x2) {
        // Check if Line 1 and Line 2 is parallel and has the same X coordinates
        return l1x1 === l2x1;
      }

      // Line 1 is parallel to Y-axis
      if (l1x1 === l1x2) {
        x = l1x1;

        const K2 = (l2y2 - l2y1) / (l2x2 - l2x1);

        // Get y coordinate of intersection point
        y = K2 * (x - l2x1) + l2y1;
      } else if (l2x1 === l2x2) {
        // Line 2 is parallel to Y-axis
        x = l2x1;

        const K1 = (l1y2 - l1y1) / (l1x2 - l1x1);

        y = K1 * (x - l1x1) + l1y1;
      }
    } else {
      // Check line intersection by angle point

      const K1 = (l1y2 - l1y1) / (l1x2 - l1x1);
      const K2 = (l2y2 - l2y1) / (l2x2 - l2x1);

      const d1 = (l1x2 * l1y1 - l1x1 * l1y2) / (l1x2 - l1x1);
      const d2 = (l2x2 * l2y1 - l2x1 * l2y2) / (l2x2 - l2x1);

      x = (d2 - d1) / (K1 - K2);
      y = (K1 * (d2 - d1)) / (K1 - K2) + d1;
    }

    return (
      // Check if coordinates in range of line segments
      (l1x1 < l1x2 ? l1x1 <= x && x <= l1x2 : l1x2 <= x && x <= l1x1) &&
      (l2x1 < l2x2 ? l2x1 <= x && x <= l2x2 : l2x2 <= x && x <= l2x1) &&
      (l1y1 < l1y2 ? l1y1 <= y && y <= l1y2 : l1y2 <= y && y <= l1y1) &&
      (l2y1 < l2y2 ? l2y1 <= y && y <= l2y2 : l2y2 <= y && y <= l2y1)
    );
  }

  /**
   * @param {number} nx1 Node leftTop X
   * @param {number} ny1 Node leftTop Y
   * @param {number} nx2 Node rightBottom X
   * @param {number} ny2 Node rightBottom Y
   * @param {number} lx1 Line X1
   * @param {number} ly1 Line Y1
   * @param {number} lx2 Line X2
   * @param {number} ly2 Line Y2
   * @return {boolean}
   */
  static #isLineIntersectNode(nx1, ny1, nx2, ny2, lx1, ly1, lx2, ly2) {
    return (
      this.#isLinesIntersect(nx1, ny1, nx2, ny1, lx1, ly1, lx2, ly2) ||
      this.#isLinesIntersect(nx2, ny1, nx2, ny2, lx1, ly1, lx2, ly2) ||
      this.#isLinesIntersect(nx2, ny2, nx1, ny2, lx1, ly1, lx2, ly2) ||
      this.#isLinesIntersect(nx1, ny2, nx1, ny1, lx1, ly1, lx2, ly2)
    );
  }

  /**
   * @param {number} x1
   * @param {number} y1
   * @param {number} x2
   * @param {number} y2
   * @param {number} [depths=5] Dep
   * @param {{ x: number; y: number; }} [prevPoint]
   * @return {{x: number; y: number;}[]}
   */
  #buildEdgePoints(x1, y1, x2, y2, depths = 5, prevPoint) {
    if (depths <= 0 || FlowChart.#isOnSameLine(x1, y1, x2, y2)) {
      return [
        { x: x1, y: y1 },
        { x: x2, y: y2 },
      ];
    }

    const canBeInPath = [
      { x: x1, y: y1 },
      [
        { x: x1, y: y2 },
        { x: x2, y: y1 },
      ].sort((a, b) => {
        if (prevPoint) {
          if (
            (FlowChart.#isOnSameLine(prevPoint.x, prevPoint.y, a.x, a.y) &&
              FlowChart.#isOnSameLine(prevPoint.x, prevPoint.y, b.x, b.y)) ||
            (!FlowChart.#isOnSameLine(prevPoint.x, prevPoint.y, a.x, a.y) &&
              !FlowChart.#isOnSameLine(prevPoint.x, prevPoint.y, b.x, b.y))
          ) {
            return 0;
          }

          if (FlowChart.#isOnSameLine(prevPoint.x, prevPoint.y, a.x, a.y)) {
            return -1;
          }

          return 1;
        }

        return 0;
      }),
      { x: x2, y: y2 },
    ];

    return canBeInPath.reduce((previousValue, currentValue) => {
      if (previousValue.length === 0) {
        previousValue.push(currentValue);

        return previousValue;
      }

      const prevPoint = previousValue[previousValue.length - 1];
      let nextPoint = false;

      if (Array.isArray(currentValue)) {
        for (const p of currentValue) {
          if (
            !this.nodes.some((node) => {
              const rect = node.getBoundingRect(false, true);

              const { x: tX, y: tY } = this.#pointTranslator(
                rect.left,
                rect.top,
              );
              rect.left = tX;
              rect.top = tY;

              const { x: prevX, y: prevY } = prevPoint;
              const { x: pX, y: pY } = p;

              return FlowChart.#isLineIntersectNode(
                rect.left,
                rect.top,
                rect.left + rect.width,
                rect.top + rect.height,
                prevX,
                prevY,
                pX,
                pY,
              );
            })
          ) {
            nextPoint = p;

            break;
          }
        }

        if (nextPoint) {
          previousValue.push(nextPoint);

          return previousValue;
        } else {
          const x = (currentValue[0].x + currentValue[1].x) / 2;
          const y = (currentValue[0].y + currentValue[1].y) / 2;

          previousValue.push(
            ...this.#buildEdgePoints(
              prevPoint.x,
              prevPoint.y,
              x,
              y,
              --depths,
              previousValue[previousValue.length - 2],
            ).slice(1),
          );

          return previousValue;
        }
      } else {
        if (
          !this.nodes.some((node) => {
            const rect = node.getBoundingRect(true);

            const { x: tX, y: tY } = this.#pointTranslator(rect.left, rect.top);
            rect.left = tX;
            rect.top = tY;

            const { x: prevX, y: prevY } = prevPoint;
            const { x: pX, y: pY } = { x: x2, y: y2 };

            return FlowChart.#isLineIntersectNode(
              rect.left,
              rect.top,
              rect.left + rect.width,
              rect.top + rect.height,
              prevX,
              prevY,
              pX,
              pY,
            );
          })
        ) {
          previousValue.push({ x: x2, y: y2 });

          return previousValue;
        } else {
          previousValue.push(
            ...this.#buildEdgePoints(
              prevPoint.x,
              prevPoint.y,
              x2,
              y2,
              --depths,
              previousValue[previousValue.length - 2],
            ).slice(1),
          );

          return previousValue;
        }
      }
    }, []);
  }

  /**
   * @param {number} x1
   * @param {number} y1
   * @param {number} x2
   * @param {number} y2
   * @param {number} x3
   * @param {number} y3
   * @return {[{x: number, y: number},{cx, cy, x: number, y: number, type: string}]}
   */
  #getRoundPoints(x1, y1, x2, y2, x3, y3) {
    let round = this.LINE_ROUND < 0 ? 0 : this.LINE_ROUND;

    const d1 = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    const d2 = Math.sqrt((x3 - x2) ** 2 + (y3 - y2) ** 2);

    if (round > d1) {
      round = d1;
    } else if (round > d2) {
      round = d2;
    }

    const t1 = 1 - round / d1;
    const t2 = round / d2;

    return [
      {
        x: (1 - t1) * x1 + t1 * x2,
        y: (1 - t1) * y1 + t1 * y2,
      },
      {
        x: (1 - t2) * x2 + t2 * x3,
        y: (1 - t2) * y2 + t2 * y3,
        cx: x2,
        cy: y2,
        type: 'Q',
      },
    ];
  }

  /**
   * Returns svg path curve by points
   *
   * @param {{ x: number; y: number; }[]} points
   * @return {string}
   */
  #getCurvePath(points) {
    let curvePath = '';

    let newPoints;

    if (points.length > 2) {
      newPoints = [points[0]];

      for (let pI = 1; pI < points.length - 1; pI++) {
        const prev = newPoints[newPoints.length - 1];
        const curr = points[pI];
        const end = points[pI + 1];

        newPoints.push(
          ...this.#getRoundPoints(prev.x, prev.y, curr.x, curr.y, end.x, end.y),
        );
      }

      newPoints.push(points[points.length - 1]);
    } else {
      newPoints = points;
    }

    const p0 = newPoints[0];

    curvePath += `M${p0.x} ${p0.y}`;

    for (const point of newPoints.slice(1)) {
      switch (point.type) {
        case 'Q':
          curvePath += `Q${point.cx} ${point.cy} ${point.x} ${point.y}`;

          break;

        default:
          curvePath += `${point.type ?? 'L'}${point.x} ${point.y}`;

          break;
      }
    }

    return curvePath;
  }

  /**
   * @param {{left?: number; top?: number; x?: number; y?: number; description?: string; backgroundImage: import('fabric/fabric-impl').Image; img?: import('fabric/fabric-impl').Image; onClick?: function; modelsCaption?: string; modelsCaptionOpts?: import('fabric/fabric-impl').IRectOptions & { onClick?: function; };}} opts
   * @return {import('fabric/fabric-impl').Group}
   */
  #buildNode(opts) {
    const {
      description,
      id = description
        ?.toString()
        .toLowerCase()
        .trim()
        .replace(/((\r\n)|\n|\s|&)+/g, '-') ?? `N${Math.random()}`,
      left = 0,
      top = 0,
      x,
      y,
      backgroundImage,
      img,
      onClick,
      modelsCaption = '0 models',
      modelsCaptionOpts: {
        onClick: modelsCaptionOnClick,
        ...modelsCaptionOpts
      } = {},
    } = Object.assign({}, opts);

    const group = new fabric.Group([], { id, onClick });
    backgroundImage.set({ id: `${id}-backgroundImage` });

    group.addWithUpdate(backgroundImage);

    const backgroundRect = backgroundImage.getBoundingRect(true);
    const groupRect = group.getBoundingRect(true);

    const captionFontSize = 14;
    const captionPaddingX = 8;
    const captionPaddingY = 4;

    /**
     * @type {import('fabric/fabric-impl').IText}
     */
    const captionText = new fabric.IText(modelsCaption, {
      id: `${id}-captionText`,
      fill: '#FFFFFF',
      left: captionPaddingX,
      top: captionPaddingY,
      fontSize: captionFontSize,
    });

    const captionTextRect = captionText.getBoundingRect(true);

    const captionRectWidth = captionTextRect.width + captionPaddingX * 2;
    const captionRectHeight = captionTextRect.height + captionPaddingY * 2;

    const captionRect = new fabric.Rect(
      Object.assign(
        {
          fill: '#8F8994',
          rx: 12,
          ry: 12,
        },
        modelsCaptionOpts,
        {
          left: 0,
          top: 0,
          width: captionRectWidth,
          height: captionRectHeight,
          objectCaching: false,
          id: `${id}-caption`,
        },
      ),
    );

    const captionGroup = new fabric.Group([captionRect, captionText], {
      top: 12,
      left: groupRect.left + groupRect.width / 2 - captionRectWidth / 2,
      id: `${id}-captionGroup`,
      onClick: modelsCaptionOnClick,
    });

    group.addWithUpdate(captionGroup);

    if (description) {
      /**
       * @type {import('fabric/fabric-impl').ITextOptions}
       */
      const textOptions = {
        fontSize: 16,
        fill: '#4F2170',
        textAlign: 'center',
        width: backgroundRect.width,
        fontWeight: 700,
        fontFamily: 'Custom Fonts',
        lineHeight: 1,
        id: `${id}-description`,
      };

      const descriptionNode = new fabric.IText(
        description.toUpperCase(),
        textOptions,
      );

      const descriptionRect = descriptionNode.getBoundingRect(true);

      descriptionNode.set({
        left: groupRect.left + groupRect.width / 2 - descriptionRect.width / 2,
        top: groupRect.top + groupRect.height - 12 - descriptionRect.height,
      });

      group.addWithUpdate(descriptionNode);
    }

    if (img) {
      const imgRect = img.getBoundingRect(true);

      img.set({
        left: groupRect.left + groupRect.width / 2 - imgRect.width / 2,
        top: groupRect.top + groupRect.height / 2 - imgRect.height / 2,
        id: `${id}-image`,
      });

      group.addWithUpdate(img);
    }

    if (typeof x === 'number' && typeof y === 'number') {
      group.set(this.getPosition(x, y));
    } else {
      group.set({ left, top });
    }

    return group;
  }

  /**
   * @param {{ x: number; y: number; }[]} linePoints
   * @param {{ grid?: boolean; arrows?: { from?: true | string; to?: true | string; }; id?: string }} [options]
   * @return {import('fabric/fabric-impl').Group}
   */
  #buildConnect(linePoints, options) {
    const {
      grid = false,
      arrows: { from: fromArr, to: toArr } = {},
      id = `E${Math.random()}`,
    } = options || {};

    let fromArrow;
    let toArrow;

    if (fromArr === true || (typeof fromArr === 'number' && !!fromArr) || fromArr === '1') {
      fromArrow = new fabric.Path('M0 0L-10 -5.7735V5.5470Z', {
        fill: '#DF8726',
        stroke: '#DF8726',
        objectCaching: false,
      });
    } else if (typeof fromArr === 'string') {
      fromArrow = new fabric.Path(fromArr, {
        fill: '#DF8726',
        stroke: '#DF8726',
        objectCaching: false,
      });
    }
    
    if (toArr === true || (typeof toArr === 'number' && !!toArr) || toArr === '1') {
      toArrow = new fabric.Path('M0 0L-10 -5.7735V5.5470Z', {
        fill: '#DF8726',
        stroke: '#DF8726',
        objectCaching: false,
      });
    } else if (typeof toArr === 'string') {
      toArrow = new fabric.Path(toArr, {
        fill: '#DF8726',
        stroke: '#DF8726',
        objectCaching: false,
      });
    }

    let line = linePoints;

    if (grid) {
      line = linePoints.map((p) => {
        const { left, top } = this.getPosition(p.x, p.y);

        return {
          x: left + this.GRID_WIDTH / 2,
          y: top + this.GRID_HEIGHT / 2,
        };
      });
    }

    /**
     * @type {import('fabric/fabric-impl').Path}
     */
    const path = new fabric.Path(this.#getCurvePath(line), {
      fill: '',
      stroke: '#DF8726',
      objectCaching: false,
      strokeWidth: 2,
    });

    /**
     * @type {import('fabric/fabric-impl').Group}
     */
    const group = new fabric.Group([path], { id });

    if (fromArrow) {
      const [p1, p2] = line.slice(0, 2);

      const fromArrowRect = fromArrow.getBoundingRect(true);

      group.addWithUpdate(
        fromArrow
          .set({
            left: p1.x - fromArrowRect.width / 2,
            top: p1.y - fromArrowRect.height / 2,
            id: `${id}-fromArrow`,
          })
          .rotate(
            (p2.x >= p1.x ? 180 : 0) +
              (Math.atan((p2.y - p1.y) / (p2.x - p1.x)) * 180) / Math.PI,
          ),
      );
    }

    if (toArrow) {
      const [p1, p2] = line.slice(-2);

      const toArrowRect = toArrow.getBoundingRect(true);

      group.addWithUpdate(
        toArrow
          .set({
            left: p2.x - toArrowRect.width / 2,
            top: p2.y - toArrowRect.height / 2,
            id: `${id}-toArrow`,
          })
          .rotate(
            (p1.x >= p2.x ? 180 : 0) +
              (Math.atan((p1.y - p2.y) / (p1.x - p2.x)) * 180) / Math.PI,
          ),
      );
    }

    return group;
  }

  /**
   * Get first connector point for node with set direction and position
   * @param {number} nx1 Left top X
   * @param {number} ny1 Left top Y
   * @param {number} nx2 Bottom right X
   * @param {number} ny2 Bottom right Y
   * @param {'left'|'top'|'right'|'bottom'} direction Node side for connector
   * @param {number} position Integer number of point position. By default, we have 11 positions for each line. 0 - center of side, -5 - top/left of side, 5 - bottom/right of side
   * @return {{x: number, y: *}|{x: *, y: number}|{x: number, y: number}}
   */
  #getDirectionPoint(nx1, ny1, nx2, ny2, direction, position = 0) {
    const padding = this.EDGE_PADDING;

    const x1 = nx1 - padding;
    const y1 = ny1 - padding;

    const x2 = nx2 + padding;
    const y2 = ny2 + padding;

    position = Math.round(position);

    const pos2 = Math.floor(this.EDGE_POSITIONS_COUNT / 2);

    let posOffset;

    if (position > pos2) {
      posOffset = pos2;
    } else if (position < -pos2) {
      posOffset = -pos2;
    } else {
      posOffset = position;
    }

    const xOffset =
      (this.GRID_WIDTH * this.EDGE_OFFSET_RANGE) / this.EDGE_POSITIONS_COUNT;
    const yOffset =
      (this.GRID_HEIGHT * this.EDGE_OFFSET_RANGE) / this.EDGE_POSITIONS_COUNT;

    switch (direction) {
      case 'left':
        return { x: x1, y: (y1 + y2) / 2 + yOffset * posOffset };

      case 'top':
        return { x: (x1 + x2) / 2 + xOffset * posOffset, y: y1 };

      case 'right':
        return { x: x2, y: (y1 + y2) / 2 + yOffset * posOffset };

      case 'bottom':
        return { x: (x1 + x2) / 2 + xOffset * posOffset, y: y2 };

      default:
        return { x: (x1 + x2) / 2, y: (y1 + y2) / 2 };
    }
  }

  /**
   * Minimum edge length line
   * @param {number} x
   * @param {number} y
   * @param {'left'|'top'|'right'|'bottom'} direction
   * @return {{x: number, y: number}}
   */
  #getStartEdgePart(x, y, direction) {
    const minLength = this.MIN_PART_EDGE_LENGTH;

    switch (direction) {
      case 'left':
        return { x: x - minLength, y };

      case 'top':
        return { x, y: y - minLength };

      case 'right':
        return { x: x + minLength, y };

      case 'bottom':
        return { x, y: y + minLength };

      default:
        return { x, y };
    }
  }

  /**
   * Add node to set
   * @param opts
   * @return {Promise<unknown>}
   */
  async addNode(opts) {
    // eslint-disable-next-line no-async-promise-executor
    const promise = new Promise(async (resolve) => {
      const { backgroundImage, img, ...otherOpts } = opts;

      const n = this.#buildNode(
        Object.assign({}, otherOpts, {
          backgroundImage: await FlowChart.imageFromUrl(backgroundImage),
          img: await FlowChart.imageFromUrl(img),
        }),
      );

      resolve(n);
    });

    this.nodePromises.push(promise);
    this.nodes.push(await promise);

    return await promise;
  }

  /**
   * @param {number} x
   * @param {number} y
   * @param {number} width
   * @param {number} height
   * @return {{ left: number; top: number; width: number; height: number; }}
   */
  buildBoundingRect(x, y, width, height) {
    const computedWidth =
      this.getPosition(x + width, 0).left -
      this.getPosition(x, 0).left -
      this.GRID_WIDTH_SPACING;
    const computedHeight =
      this.getPosition(0, y + height).top -
      this.getPosition(0, y).top -
      this.GRID_HEIGHT_SPACING;

    return {
      ...this.getPosition(x, y),
      width: computedWidth,
      height: computedHeight,
    };
  }

  /**
   * @param {import('fabric/fabric-impl').Object} node
   * @param {{ [p: string]: any; }} [opts]
   * @return {void}
   */
  addCustomNode(node, opts) {
    this.customNodes.push(node.set(opts));
  }

  /**
   * Add edge to set
   *
   * @param {string|{x: number; y:number;}} start String node id of start point or coords
   * @param {string|{x: number; y:number;}} end String node id of end point or coords
   * @param {{ arrows?: { to?: boolean | string; toDir?: ConnectDirection; from?: boolean | string; fromDir?: ConnectDirection; toPos?: number; fromPos?: number }, magnetPoints?: {x: number; y: number; }[]}} [opts] Edge options
   */
  addEdge(start, end, opts) {
    this.rawEdges.push({ start, end, opts });
  }

  /**
   * Translate point coordinates
   * @param {number} x
   * @param {number} y
   * @return {{x: number; y: number}}
   */
  #pointTranslator(x, y) {
    const firstNode = this.nodes[0];

    const groupRect = firstNode.group?.getBoundingRect();

    return {
      x: x + groupRect.width / 2,
      y: y + groupRect.height / 2,
    };
  }

  /**
   * Build edges to draw
   */
  #buildEdges() {
    for (const e of this.rawEdges) {
      const {
        start,
        end,
        opts: {
          arrows: { to, toDir, from, fromDir, fromPos, toPos } = {},
          magnetPoints,
        } = {},
      } = e;

      const edge = [];

      let startNode;
      let startNodeCenter;

      if (typeof start === 'string') {
        startNode = this.nodes.find((v) => v.id === start);

        if (!startNode) {
          continue;
        }

        startNodeCenter = startNode.getCenterPoint();
        startNodeCenter = this.#pointTranslator(
          startNodeCenter.x,
          startNodeCenter.y,
        );
      } else if (
        typeof start === 'object' &&
        typeof start.x === 'number' &&
        typeof start.y === 'number'
      ) {
        startNodeCenter = start;
      } else {
        break;
      }

      let endNode;
      let endNodeCenter;

      if (typeof end === 'string') {
        endNode = this.nodes.find((v) => v.id === end);

        if (!endNode) {
          continue;
        }

        endNodeCenter = endNode.getCenterPoint();
        endNodeCenter = this.#pointTranslator(endNodeCenter.x, endNodeCenter.y);
      } else if (
        typeof end === 'object' &&
        typeof end.x === 'number' &&
        typeof end.y === 'number'
      ) {
        endNodeCenter = end;
      } else {
        break;
      }

      const startDir =
        startNode &&
        (fromDir ||
          FlowChart.#getConnectDirection(
            startNodeCenter.x,
            startNodeCenter.y,
            endNodeCenter.x,
            endNodeCenter.y,
          ));
      const endDir =
        endNode &&
        (toDir ||
          FlowChart.#getConnectDirection(
            endNodeCenter.x,
            endNodeCenter.y,
            startNodeCenter.x,
            startNodeCenter.y,
          ));

      let startPoint;
      let minLengthPartStartPoint;

      if (startDir) {
        const rect = startNode.getBoundingRect(false, true);

        const { x: tX, y: tY } = this.#pointTranslator(rect.left, rect.top);

        rect.left = tX;
        rect.top = tY;

        startPoint = this.#getDirectionPoint(
          rect.left,
          rect.top,
          rect.left + rect.width,
          rect.top + rect.height,
          startDir,
          fromPos,
        );
        minLengthPartStartPoint = this.#getStartEdgePart(
          startPoint.x,
          startPoint.y,
          startDir,
        );
      } else {
        startPoint = startNodeCenter;
      }

      let endPoint;
      let minLengthPartEndPoint;

      if (endDir) {
        const rect = endNode.getBoundingRect(false, true);

        const { x: tX, y: tY } = this.#pointTranslator(rect.left, rect.top);

        rect.left = tX;
        rect.top = tY;

        endPoint = this.#getDirectionPoint(
          rect.left,
          rect.top,
          rect.left + rect.width,
          rect.top + rect.height,
          endDir,
          toPos,
        );
        minLengthPartEndPoint = this.#getStartEdgePart(
          endPoint.x,
          endPoint.y,
          endDir,
        );
      } else {
        endPoint = endNodeCenter;
      }

      edge.push(startPoint);

      let sP = startPoint;

      if (minLengthPartStartPoint) {
        edge.push(minLengthPartStartPoint);

        sP = minLengthPartStartPoint;
      }

      let eP = endPoint;

      if (minLengthPartEndPoint) {
        eP = minLengthPartEndPoint;
      }

      if (magnetPoints && Array.isArray(magnetPoints) && magnetPoints.length) {
        const mPoints = magnetPoints.map((p) => {
          const pos = this.getPosition(p.x, p.y);

          return { x: pos.left, y: pos.top };
        });

        for (let i = 0; i < mPoints.length; i++) {
          const mP = mPoints[i];

          if (i === 0) {
            edge.push(
              ...this.#buildEdgePoints(
                sP.x,
                sP.y,
                mP.x,
                mP.y,
                1,
                edge[edge.length - 2],
              ),
            );
          }

          if (i === mPoints.length - 1) {
            edge.push(
              ...this.#buildEdgePoints(
                mP.x,
                mP.y,
                eP.x,
                eP.y,
                1,
                edge[edge.length - 1],
              ),
            );
          }

          if (i > 0 && i < magnetPoints.length - 1) {
            const pP = mPoints[i - 1];

            edge.push(
              ...this.#buildEdgePoints(
                pP.x,
                pP.y,
                mP.x,
                mP.y,
                1,
                edge[edge.length - 1],
              ),
            );
          }
        }
      } else {
        edge.push(
          ...this.#buildEdgePoints(
            sP.x,
            sP.y,
            eP.x,
            eP.y,
            5,
            edge[edge.length - 2],
          ),
        );
      }

      if (minLengthPartEndPoint) {
        edge.push(minLengthPartEndPoint);
      }

      edge.push(endPoint);

      const filtered = edge.filter(
        (value, index, array) =>
          !array[index + 1] ||
          !(value.x === array[index + 1].x && value.y === array[index + 1].y),
      );

      this.edges.push(
        this.#buildConnect(filtered, {
          grid: false,
          arrows: { from, to },
        }),
      );
    }
  }

  #addEvents() {
    if (!this.canvas.get('eventsInitialized')) {
      this.canvas.on('mouse:up', (e) => {
        if (typeof e.target?.onClick === 'function') {
          e.target.onClick(e);
        }
      });

      this.canvas.set('eventsInitialized', true);
    }
  }

  drawAwaiters = [];

    /**
     * Draw all nodes and edges
     * @return {Promise<void>}
     */
    async draw() {
      let resolve;
    
      const functionPromise = new Promise((r) => {
        resolve = r;
      });
      
      await Promise.all(this.drawAwaiters);
      
      this.drawAwaiters.push(functionPromise);
      
      await Promise.all(this.nodePromises);
    
      const customNodesGroup = new fabric.Group(this.customNodes, {
        id: 'custom-nodes-group',
      });
    
      const nodesGroup = new fabric.Group(this.nodes, {
        id: 'nodes-group',
      });
      
      this.edges = [];
      this.#buildEdges();
    
      const edgesGroup = new fabric.Group(this.edges, {
        id: 'edges-group',
      });
    
      const mainGroup = new fabric.Group(
        [customNodesGroup, nodesGroup, edgesGroup],
        {
          id: 'main-group',
          hasControls: false,
          hasBorders: false,
          lockMovementX: true,
          lockMovementY: true,
          selectable: false,
        },
      );
    
      const groupRect = mainGroup.getBoundingRect(true);
      const scaleFactor = this.canvas.getWidth() / groupRect.width;
    
      mainGroup.set({
        scaleX: scaleFactor,
        scaleY: scaleFactor,
      });
    
      this.canvas.add(mainGroup);
    
      const blockElementOptions = {
        hasControls: false,
        hasBorders: false,
        lockMovementX: true,
        lockMovementY: true,
        selectable: false,
      };
    
      const nodesToCanvas = Array.prototype.concat(
        this.nodes
          .filter((node) => typeof node.onClick === 'function')
          .map((node) => {
            return node.set(blockElementOptions);
          }),
        ...this.nodes.map((node) => {
          return (
            node
              .getObjects?.()
              .filter((node) => typeof node.onClick === 'function')
              .map((o) => {
                return o.set(blockElementOptions);
              }) || []
          );
        }),
      );
    
      this.canvas.add(...nodesToCanvas);
    
      edgesGroup.bringToFront();
      nodesGroup.bringToFront();
    
      this.canvas.renderAll();
    
      mainGroup.centerH();
      mainGroup.set({ top: 0 });
    
      this.canvas.set({ selection: false });
    
      this.#addEvents();
    
      resolve(true);
    }
    
    /**
     * Clear all canvas elements and redraw it.
     * Can be used after resize canvas wrapper
     *
     * @return {Promise<void>}
     */
    async redraw() {
      await Promise.all(this.drawAwaiters);
    
      this.canvas.clear();
    
      await this.draw();
    }

  /**
   * Clear all chart data
   */
  clear() {
    this.nodes = [...FlowChart.#getInitNodes()];
    this.customNodes = [];
    this.nodePromises = [];
    this.edges = [];
    this.rawEdges = [];

    this.canvas.clear();
  }
}
